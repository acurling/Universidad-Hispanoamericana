﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1NathalieMirandaVenegas
{
    class Clsservicios
    {
        String modifcedula;
        String modifnombre;
        String modifapellido1;
        String modifapellido2;
        int modifts;
        int modiffactura;
        double modifmontop;
        double modifmontopc;

        String[] Numpago = new string[10];
        String[] cedula = new string[10];
        String[] nombre = new string[10];
        String[] apellido1 = new string[10];
        String[] apellido2 = new string[10];
        int[] Numfactura = new int[10];
        int[] tiposervicio = new int[10];
        double[] MontoPagar = new double[10];
        double[] Montocomision = new double[10];
        double[] Montodeducido = new double[10];
        double[] Montopagacliente = new double[10];
        double[] Vuelto = new double[10];
        string Date;
        string datetime;
        int caja;
        int posicion;
        bool esnumero;
        int valor;

        double num1 = 0.04;
        double num2 = 0.055;
        double num3 = 0.065;

        public Clsservicios()
        {
            posicion = 0;
        }

        public Clsservicios(int pos)
        {
            posicion = pos;
        }

        // metodos ( Inicializar,Incluir,Consultar,Modificar, Eliminar ,Submenu

        public void inicializar()
        {
            for (int i = 0; i < nombre.Length; i++)
            {
                nombre[i] = "";
                cedula[i] = "";
                apellido1[i] = "";
                apellido2[i] = "";
                Numpago[i] = "";
                Numfactura[i] = 1;
                Montocomision[i] = 0;
                Montodeducido[i] = 0;
                Montopagacliente[i] = 0;
                Vuelto[i] = 0;


            }
            posicion = 0;
        }

        public void RealizarPagos()
        {
            char opcion;
            opcion = 's';


            while ((opcion != 'n') && (posicion < 10))
            {
                do
                {
                    Console.WriteLine("Ingrese el numero de pago ");
                    Numpago[posicion] = Console.ReadLine();
                    esnumero = int.TryParse(Numpago[posicion], out valor);
                }
                while (!esnumero);

                Console.WriteLine("Ingrese el numero de factura");
                Numfactura[posicion] = Convert.ToInt32(Console.ReadLine());



                Date = DateTime.Now.ToString("dd-MM-yyyy");

                datetime = DateTime.Now.ToString("hh:mm:ss tt");

                Console.WriteLine("Digite el nombre : ");
                nombre[posicion] = Console.ReadLine();
                Console.WriteLine("Digite el primer apellido : ");
                apellido1[posicion] = Console.ReadLine();
                Console.WriteLine("Digite el segundo apellido: ");
                apellido2[posicion] = Console.ReadLine();
                do
                {
                    Console.WriteLine("Digite la cedula");
                    cedula[posicion] = Console.ReadLine();
                    esnumero = int.TryParse(cedula[posicion], out valor);
                }
                while (!esnumero);

                Console.WriteLine("Ingrese  el tipo de servicio 1=Electricidad , 2= Telefono , 3=Agua");
                tiposervicio[posicion] = Convert.ToInt32(Console.ReadLine());


                if (tiposervicio[posicion] == 1)
                {
                    Montocomision[posicion] = MontoPagar[posicion] * num1;
                    Montodeducido[posicion] = MontoPagar[posicion] - Montocomision[posicion];


                }
                else if (tiposervicio[posicion] == 2)
                {
                    Montocomision[posicion] = MontoPagar[posicion] * num2;
                    Montodeducido[posicion] = MontoPagar[posicion] - Montocomision[posicion];


                }
                else if (tiposervicio[posicion] == 3)
                {
                    Montocomision[posicion] = MontoPagar[posicion] * num3;
                    Montodeducido[posicion] = MontoPagar[posicion] - Montocomision[posicion];


                }




                Console.WriteLine("Ingrese el monto a pagar");
                MontoPagar[posicion] = Convert.ToDouble(Console.ReadLine());


                Console.WriteLine("Ingrese con cuanto dinero va cancelar");
                Montopagacliente[posicion] = Convert.ToInt32(Console.ReadLine());

                if (Montopagacliente[posicion] < MontoPagar[posicion])
                {
                    Console.WriteLine("El monto ingresado con el cual va cancelar es menor al monto que debe cancelar");
                    Console.WriteLine("Ingrese con cuanto dinero va cancelar");
                    Montopagacliente[posicion] = Convert.ToInt32(Console.ReadLine());
                }


                Vuelto[posicion] = Montopagacliente[posicion] - MontoPagar[posicion];

                Random rnd = new Random();
                caja = rnd.Next(1, 4);



                posicion++;
                Console.WriteLine("Desea continuar s/n");
                opcion = Convert.ToChar(Console.ReadLine());


            }
        }

        public void ConsultarPagos()
        {
            Console.WriteLine("Digite el número de pago que desea consultar");
            string npago = Console.ReadLine();

            for (int i = 0; i < Numpago.Length; i++)
            {
                if (npago.Equals(Numpago[i]))

                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Clear();
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("***Sistema Pago de Servicios***");
                    Console.WriteLine("Tienda La Favorita -Ingreso de datos ");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("");
                    Console.WriteLine($"Fecha:  {Date}");
                    Console.WriteLine($"Hora:  {datetime}");
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine($"Número de pago : {Numpago[i]} ");
                    Console.WriteLine($"Número de factura : {Numfactura[i]}");
                    Console.WriteLine($"Nombre : {nombre[i]}");
                    Console.WriteLine($"Cédula : {cedula[i]}");
                    Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                    Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                    Console.WriteLine("");
                    Console.WriteLine($"Número de Caja  : {caja}");
                    Console.WriteLine($"Tipo de servicio : {tiposervicio[i]}");
                    Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                    Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                    Console.WriteLine($"Vuelto : {Vuelto[i]}");
                    Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                    Console.WriteLine($"Monto deducido : {Montodeducido[i]}");


                }
                else if (Numpago[posicion] != npago)
                {
                    Console.WriteLine("El pago no se encuentra registrado");

                }

            }

        }


        Clsservicios mod = new Clsservicios();
        public void ModificarEstudiante()

        {

            int op = 0;
            Console.WriteLine("Digite el número de pago que desea modificar");
            string npago = Console.ReadLine();

            for (int i = 0; i < Numpago.Length; i++)
            {

                if (npago.Equals(cedula[i]))
                {
                    do
                    {
                        Console.WriteLine("Elija que desea modificar");
                        Console.WriteLine("1-Número de cedula");
                        Console.WriteLine("2-Nombre");
                        Console.WriteLine("3-Apellido 1");
                        Console.WriteLine("4-Apellido 2");
                        Console.WriteLine("5-Tipo de servicio");
                        Console.WriteLine("6-Número de factura");
                        Console.WriteLine("7-Monto Pagar");
                        Console.WriteLine("8-Monto Paga cliente");
                        Console.WriteLine("Elija una opción ");
                        op = int.Parse(Console.ReadLine());

                        switch (op)
                        {
                            case 1: mod.ced();


                                break;
                            case 2:mod.nom();


                                break;
                            case 3:mod.ape1();

                                break;

                            case 4: mod.ape2();

                                break;

                            case 5:mod.Ts();


                                break;
                            case 6: mod.Numf();
                                break;

                            case 7:
                                mod.Montop();
                                break;
                            case 8:
                                mod.Montopc();
                                break;
                         
                            case 9: break;

                            default:
                                break;
                        }
                    } while (op != 9);


                }
            }
        }

        public void ced()
        {

            Console.WriteLine("Digite la cedula");
            modifcedula = cedula[posicion];


        }
    

    
        public void nom()
        {
            Console.WriteLine("Digite el nombre");
            modifnombre= nombre[posicion];

        }

        public void ape1()
        {
            Console.WriteLine("Digite el primer apellido");
            modifapellido1 = apellido1[posicion];

        }

        public void ape2()
        {
            Console.WriteLine("Digite el segundo apellido");
            modifapellido2 = apellido2[posicion];

        }

        public void Ts()
        {
            Console.WriteLine("Digite el tipo de servicio 1= Electricidad , 2= Telefono  3=Agua");
            modifts = tiposervicio[posicion];

        }
        public void Numf()
        {
            Console.WriteLine("Digite el número de factura");
            modiffactura = Numfactura[posicion];

        }
        public void Montop()
        {
            Console.WriteLine("Digite el monto a pagar");
            modifmontop = MontoPagar[posicion];

        }

        public void Montopc()
        {
            Console.WriteLine("Digite el monto a pagar cliente");
            modifmontopc = Montopagacliente[posicion];

        }

        

        public void EliminarPago()
        {

            Console.WriteLine("Digite el numero de pago que desea eliminar ");
            string nump = Console.ReadLine();
            Boolean disponible = false;
            char opcion;
            opcion = 's';

            while ((opcion != 'n') && (posicion < 10))
            {
                for (int i = 0; i < Numpago.Length; i++)
                {
                    if (Numpago[i] == nump)
                    {
                        Console.WriteLine("La información correspondiente a ese número de pago es:");
                        Console.WriteLine("");

                        Console.WriteLine("******************************************************************");
                        Console.WriteLine($"Número de pago : {Numpago[i]} ");
                        Console.WriteLine($"Nombre : {nombre[i]}");
                        Console.WriteLine($"Cédula : {cedula[i]}");
                        Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                        Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                        Console.WriteLine("");
                        Console.WriteLine($"Número de Caja  : {caja}");
                        Console.WriteLine($"Tipo de servicio : {tiposervicio}");
                        Console.WriteLine($"Número de factura : {Numfactura[i]}");
                        Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                        Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                        Console.WriteLine($"Vuelto : {Vuelto[i]}");
                        Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                        Console.WriteLine($"Monto deducido : {Montodeducido[i]}");


                        Console.WriteLine("Está seguro que desea eliminarlo s/n");
                        opcion = Convert.ToChar(Console.ReadLine());
                        Numpago[i] = "";
                        disponible = true;
                    }

                    if (disponible == true)
                    {
                        Numpago[i] = "";
                        disponible = true;
                        Console.WriteLine("El pago fue eliminado");
                        break;

                    }
                    else if (!disponible)
                    {
                        Console.WriteLine("Pago no se encuentra registrado");


                    }
                    else if (disponible == false)
                    {

                        Console.WriteLine("La información no fue eliminada");
                        break;
                    }


                }



                posicion++;

            }

        }

        public void Reportetodospagos()
        {
            Console.WriteLine(Numpago[posicion]);

            for (int i = 0; i < Numpago.Length; i++)
            {

                {
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("***Sistema Pago de Servicios***");
                    Console.WriteLine("Tienda La Favorita -Ingreso de datos ");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("");
                    Console.WriteLine($"Fecha:  {Date}");
                    Console.WriteLine($"Hora:  {datetime}");
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine($"Número de pago : {Numpago[i]} ");
                    Console.WriteLine($"Nombre : {nombre[i]}");
                    Console.WriteLine($"Cédula : {cedula[i]}");
                    Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                    Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                    Console.WriteLine("");
                    Console.WriteLine($"Número de Caja  : {caja}");
                    Console.WriteLine($"Tipo de servicio : {tiposervicio}");
                    Console.WriteLine($"Número de factura : {Numfactura[i]}");
                    Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                    Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                    Console.WriteLine($"Vuelto : {Vuelto[i]}");
                    Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                    Console.WriteLine($"Monto deducido : {Montodeducido[i]}");
                    break;
                }

            }

        }


        public void reporteservicios()
        {
            Console.WriteLine("Ingrese la opción que desea 1=Recibo luz , 2=Reibo telefono , 3=Recibo de agua");
            tiposervicio[posicion] = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < Numpago.Length; i++)
            {

                if (tiposervicio[posicion] == 1)
                {

                    Console.WriteLine("=================================================================");
                    Console.WriteLine("***Sistema Pago de Servicios***");
                    Console.WriteLine("Tienda La Favorita -Ingreso de datos ");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("");
                    Console.WriteLine($"Fecha:  {Date}");
                    Console.WriteLine($"Hora:  {datetime}");
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine($"Número de pago : {Numpago[i]} ");
                    Console.WriteLine($"Nombre : {nombre[i]}");
                    Console.WriteLine($"Cédula : {cedula[i]}");
                    Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                    Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                    Console.WriteLine("");
                    Console.WriteLine($"Número de Caja  : {caja}");
                    Console.WriteLine($"Tipo de servicio : {tiposervicio}");
                    Console.WriteLine($"Número de factura : {Numfactura[i]}");
                    Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                    Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                    Console.WriteLine($"Vuelto : {Vuelto[i]}");
                    Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                    Console.WriteLine($"Monto deducido : {Montodeducido[i]}");


                }
                else if (tiposervicio[posicion] == 2)
                {
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("***Sistema Pago de Servicios***");
                    Console.WriteLine("Tienda La Favorita -Ingreso de datos ");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("");
                    Console.WriteLine($"Fecha:  {Date}");
                    Console.WriteLine($"Hora:  {datetime}");
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine($"Número de pago : {Numpago[i]} ");
                    Console.WriteLine($"Nombre : {nombre[i]}");
                    Console.WriteLine($"Cédula : {cedula[i]}");
                    Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                    Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                    Console.WriteLine("");
                    Console.WriteLine($"Número de Caja  : {caja}");
                    Console.WriteLine($"Tipo de servicio : {tiposervicio}");
                    Console.WriteLine($"Número de factura : {Numfactura[i]}");
                    Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                    Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                    Console.WriteLine($"Vuelto : {Vuelto[i]}");
                    Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                    Console.WriteLine($"Monto deducido : {Montodeducido[i]}");


                }
                else if (tiposervicio[posicion] == 3)
                {
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("***Sistema Pago de Servicios***");
                    Console.WriteLine("Tienda La Favorita -Ingreso de datos ");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("");
                    Console.WriteLine($"Fecha:  {Date}");
                    Console.WriteLine($"Hora:  {datetime}");
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine($"Número de pago : {Numpago[i]} ");
                    Console.WriteLine($"Nombre : {nombre[i]}");
                    Console.WriteLine($"Cédula : {cedula[i]}");
                    Console.WriteLine($"Apellido 1 : {apellido1[i]}");
                    Console.WriteLine($"Apellido 2 : {apellido2[i]}");
                    Console.WriteLine("");
                    Console.WriteLine($"Número de Caja  : {caja}");
                    Console.WriteLine($"Tipo de servicio : {tiposervicio}");
                    Console.WriteLine($"Número de factura : {Numfactura[i]}");
                    Console.WriteLine($"Monto a pagar : {MontoPagar[i]}");
                    Console.WriteLine($"Paga con : {Montopagacliente[i]}");
                    Console.WriteLine($"Vuelto : {Vuelto[i]}");
                    Console.WriteLine($"Monto comisión : {Montocomision[i]}");
                    Console.WriteLine($"Monto deducido : {Montodeducido[i]}");

                }

            }



        }
     public void Reportecaja()
        {
            Console.WriteLine("Ingrese el número de caja que sea consultar");
            Random rnd = new Random();
            caja = rnd.Next(1, 4);


        }

        public void ReporteComision()
        {
            Console.WriteLine($"La comision es de :" + Montocomision[posicion]);

        }

}
}





    













