﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1NathalieMirandaVenegas
{
    class Clsmenu
    {
        static int opcion;
        static Clsservicios ser = new Clsservicios();
        static Submenu Menureportes= new Submenu();

        public static void principal()
        {
            opcion = 0;

            do
            {
                Console.WriteLine("*****MENU*****");
                Console.WriteLine("1- Inicializar");
                Console.WriteLine("2- Realizar Pagos");
                Console.WriteLine("3- Consultar Pagos");
                Console.WriteLine("4- Modificar Pagos");
                Console.WriteLine("5- Eliminar Pagos ");
                Console.WriteLine("6-Submenú Reportes");
                Console.WriteLine("7-Salir");
                Console.WriteLine("Digite su opcion");
                opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        ser.inicializar();

                        break;
                    case 2:
                        ser.RealizarPagos();

                        break;
                    case 3:
                        ser.ConsultarPagos();
                        break;
                        
                    case 4:
                        ser.ModificarEstudiante();
                        break;

                    case 5:
                       ser.EliminarPago();

                        break;
                    case 6:Menureportes.SubmenuReportes();
                 
                        break;

                    case 7: break;

                    default:
                        break;
                }
            } while (opcion != 7);// Mientras la opcion sea diferente de 7 porque es la opcion para salir
        }
    }
}

