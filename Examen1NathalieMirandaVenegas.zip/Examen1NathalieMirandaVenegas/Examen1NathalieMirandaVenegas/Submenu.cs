﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1NathalieMirandaVenegas
{
    class Submenu
    {
        Clsmenu menuprincipal = new Clsmenu();
        Clsservicios ser = new Clsservicios();

        public void SubmenuReportes()

        {
            int opcion = 0;
            do
            {
                Console.WriteLine("*****Submenú Reportes *****");
                Console.WriteLine("1- Reporte todos los pagos ");
                Console.WriteLine("2- Reporte por tipo servicio");
                Console.WriteLine("3- Reporte por caja ");
                Console.WriteLine("4- Reporte dinero comisión ");
                Console.WriteLine("5- Regresar al menú principal ");
                Console.WriteLine("Digite su opcion");
                opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        ser.Reportetodospagos();

                        break;
                    case 2:
                        ser.reporteservicios();

                        break;
                    case 3: ser.Reportecaja();
                        
                        break;

                    case 4: ser.ReporteComision();


                        break;
                    case 5:Clsmenu.principal();
                        
                        break;
                    

                    case 6: break;

                    default:
                        break;
                }
            } while (opcion != 5);
        }




        }
    }


