﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Tarea_Prueba_de_inteligencia
{
    public partial class Pag_Principal : System.Web.UI.Page
    {
        protected void Iniciar_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Pregunta_1.aspx");
        }

        protected void Agregar_Click(object sender, EventArgs e)
        {
            ClsInfo.Nom = TbNom.Text;
            ClsInfo.Fecha = TbFecha.Text;
            ClsInfo.Gen = LGen.Text;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Reportes.aspx");
        }
    }
}