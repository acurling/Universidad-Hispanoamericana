﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Tarea_Prueba_de_inteligencia
{
    public partial class Pregunta_1 : System.Web.UI.Page
    {
        protected void Preg2_Click(object sender, EventArgs e)
        {

            if (rb1.Checked)
            {
                ClsInfo.Resp1 = "A";
            }
            else if (rb2.Checked)
            {
                ClsInfo.Resp1 = "B";
            }
            else if (rb3.Checked)
            {
                ClsInfo.Resp1 = "C";
            }
            else if (rb4.Checked)
            {
                ClsInfo.Resp1 = "D";
            }
            else if (rb5.Checked)
            {
                ClsInfo.Resp1 = "E";
            }
            else if (rb6.Checked)
            {
                ClsInfo.Resp1 = "F";
            }


            Response.Redirect("Pregunta2.aspx");
        }
    }
}