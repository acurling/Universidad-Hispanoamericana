﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Tarea_Prueba_de_inteligencia
{
    public partial class Final : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TBNom.Text = ClsInfo.Nom;
            TBFecha.Text = ClsInfo.Fecha;
            TBGenero.Text = ClsInfo.Gen;
            TBR1.Text = ClsInfo.Resp1;
            TBR2.Text = ClsInfo.Resp2;
            TBR3.Text = ClsInfo.Resp3;

            if (!ClsInfo.Resp1.Equals("F"))
            {
                TBR1.Text.Equals(ClsInfo.Resp1);
                TBR1.BackColor = System.Drawing.Color.Red;
            }
            else
            {
                TBR1.Text.Equals(ClsInfo.Resp1);
                TBR1.BackColor = System.Drawing.Color.Green;
            }

            if (!ClsInfo.Resp2.Equals("B"))
            {
                TBR2.Text.Equals(ClsInfo.Resp2);
                TBR2.BackColor = System.Drawing.Color.Red;
            }
            else
            {
                TBR2.Text.Equals(ClsInfo.Resp2);
                TBR2.BackColor = System.Drawing.Color.Green;
            }

            if (!ClsInfo.Resp3.Equals("A"))
            {

                TBR3.Text.Equals(ClsInfo.Resp3);
                TBR3.BackColor = System.Drawing.Color.Red;
            }
            else
            {
                TBR3.Text.Equals(ClsInfo.Resp3);
                TBR3.BackColor = System.Drawing.Color.Green;
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Reportes.aspx");
        }

        protected void Iniciar_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Pag_Principal.aspx");
        }

    }
}