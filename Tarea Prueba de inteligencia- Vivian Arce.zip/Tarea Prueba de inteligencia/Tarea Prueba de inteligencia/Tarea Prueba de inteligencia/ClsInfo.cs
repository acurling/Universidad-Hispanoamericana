﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tarea_Prueba_de_inteligencia
{
    public class ClsInfo
    {
        public static string Nom { get; set; }
        public static string Fecha { get; set; }
        public static string Gen { get; set; }
        public static string Resp1 { get; set; }
        public static string Resp2 { get; set; }
        public static string Resp3 { get; set; }

    }
}