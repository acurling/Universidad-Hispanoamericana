﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;

namespace Tarea_Prueba_de_inteligencia
{
    public partial class Pregunta_2 : System.Web.UI.Page
    {

        protected void Preg2_Click(object sender, EventArgs e)
        {
            if (rb1.Checked)
            {
                ClsInfo.Resp2 = "A";
            }
            else if (rb2.Checked)
            {
                ClsInfo.Resp2 = "B";
            }
            else if (rb3.Checked)
            {
                ClsInfo.Resp2 = "C";
            }
            else if (rb4.Checked)
            {
                ClsInfo.Resp2 = "D";
            }
            else if (rb5.Checked)
            {
                ClsInfo.Resp2 = "E";
            }
            else if (rb6.Checked)
            {
                ClsInfo.Resp2 = "F";
            }

            Response.Redirect("Pregunta_3.aspx");
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
    
