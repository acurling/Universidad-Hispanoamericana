﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Tarea_Prueba_de_inteligencia
{
    public partial class FFinal : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            TBNom.Text = ClsInfo.Nom;
            TBFecha.Text = ClsInfo.Fecha;
            TBGenero.Text = ClsInfo.Gen;
            TBR1.Text = ClsInfo.Resp1;
            TBR2.Text = ClsInfo.Resp2;
            TBR3.Text = ClsInfo.Resp3;
            int puntaje = 0;
            int buena = 0;
            int mala = 0;
            


            if (!ClsInfo.Resp1.Equals("F"))
            {
                TBR1.Text.Equals(ClsInfo.Resp1);
                TBR1.BackColor = System.Drawing.Color.Red;
                mala = mala + 1;
            }

            else
            {
                TBR1.Text.Equals(ClsInfo.Resp1);
                TBR1.BackColor = System.Drawing.Color.Green;
                puntaje = puntaje + 3;
                buena = buena + 1;
            }

            if (!ClsInfo.Resp2.Equals("B"))
            {
                TBR2.Text.Equals(ClsInfo.Resp2);
                TBR2.BackColor = System.Drawing.Color.Red;
                mala = mala + 1;
            }

            else
            {
                TBR2.Text.Equals(ClsInfo.Resp2);
                TBR2.BackColor = System.Drawing.Color.Green;
                puntaje = puntaje + 3;
                buena = buena + 1;
            }

            if (!ClsInfo.Resp3.Equals("A"))
            {
                TBR3.Text.Equals(ClsInfo.Resp3);
                TBR3.BackColor = System.Drawing.Color.Red;
                mala = mala + 1;
            }

            else
            {
                TBR3.Text.Equals(ClsInfo.Resp3);
                TBR3.BackColor = System.Drawing.Color.Green;
                puntaje = puntaje + 3;
                buena = buena + 1;
            }

            TBPuntaje.Text = Convert.ToString(puntaje);
            TBBuenas.Text = Convert.ToString(buena);
            TBMalas.Text = Convert.ToString(mala);
        }


        protected void Iniciar_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Pag_Principal.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Reportes.aspx");
        }

        protected void Preg2_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["PruebaDeInteligenciaConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            conexion.Open();
            SqlCommand comando = new SqlCommand("INSERT INTO PruebaDeInteligencia VALUES('" + ClsInfo.Nom + "', '" + ClsInfo.Fecha + "', '" + ClsInfo.Gen + "', '" + ClsInfo.Resp1 + "','" + ClsInfo.Resp2 + "', '" + ClsInfo.Resp3 + "')", conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }
    }
}