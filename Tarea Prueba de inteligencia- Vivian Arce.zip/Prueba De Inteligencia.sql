Use PruebaDeInteligencia

Create table PruebaDeInteligencia(
Id int identity (1,1), 
Nombre varchar (20) not null,
Genero varchar (20),
Fecha varchar (20),
R1 char (1),
R2 char (1),
R3 char (1)

constraint PK_ID primary key (Id)
)
insert PruebaDeInteligencia ()

drop table PruebaDeInteligencia


/*Unir tablas 
Select nombredetabla.atributo
from nombretabla1 inner join nombretabla2 on nombretabla1.PK = nombretabla2.FK
*/

delete

insert into PruebaDeInteligencia (Nombre, Genero, Fecha, R1, R2, R3) values ('Carlitos', 'Masculino', '7/11/2021', 'A', 'B', 'C')
select * from PruebaDeInteligencia