﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1CarlosDanielNuñez
{
    class ClsServicioPublico
    {
        // Atributos
        String[] numeroPago = new string[10];
        String[] fecha = new string[10];
        String[] hora = new string[10];
        String[] cedula = new string[15];
        String[] nombre = new string[10];
        String[] apellido1 = new string[10];
        String[] apellido2 = new string[10];
        int[] numeroCaja = new int[10];
        String[] tipoServicio = new string[10];
        String[] numeroFactura = new string[10];
        String[] montoPagar = new string[10];
        String[] montoComision = new string[10];
        String[] montoDeducido = new string[10];
        String[] montoPagaCliene = new string[10];
        String[] montoVuelto = new string[10];

        int pos;
        int numpago;
        String buscarpago;
        String nuevodato;
        String opcionmodificar;
        String opcioneliminar;
        String opcionseleccionada;
        int fila = 14;
        int electricidad = 0;
        int agua = 0;
        int telefono = 0;
        double totalComElec = 0;
        double totalComTel = 0;
        double totalComAgua = 0;
        int TotalTransacciones = 0;
        double totalComisionado = 0;
        int montoTotal = 0;
        int totalReg = 0;

        public ClsServicioPublico()
        {
            pos = 0;
            numpago = 1;
        }

        public void InicializarVectores()
        {
            for (int i = 0; i < fecha.Length; i++)
            {
                numeroPago[i] = "";
                fecha[i]="";
                hora[i] = "";
                cedula[i] = "";
                nombre[i] = "";
                apellido1[i] = "";
                apellido2[i] = "";
                numeroCaja[i] = 0;
                tipoServicio[i] = "";
                numeroFactura[i] = "";
                montoPagar[i] = "";
                montoComision[i] = "";
                montoDeducido[i] = "";
                montoPagaCliene[i] = "";
                montoVuelto[i] = "";
            }
        }
        public void RealizarPago()
        {
            char opcion = 's';
            do
            {
                
                numeroPago[pos] = Convert.ToString(numpago);

                fecha[pos]= DateTime.Now.ToString("dd-MM-yyyy");

                hora[pos] = DateTime.Now.ToString("hh:mm:ss");
                
                Console.WriteLine("Digite la cedula");
                cedula[pos] = Console.ReadLine();

                Console.WriteLine("Digite el nombre");
                nombre[pos] = Console.ReadLine();

                Console.WriteLine("Digite el primer apellido");
                apellido1[pos] = Console.ReadLine();

                Console.WriteLine("Digite el segundo apellido");
                apellido2[pos] = Console.ReadLine();

                Random numeroCajaR = new Random();
                numeroCaja[pos] = numeroCajaR.Next(1, 4);
               
                Console.WriteLine("Digite el tipo de servicio a pagar");
                Console.WriteLine("1-Electricidad 2-Telefono 3-Agua");
                tipoServicio[pos] = Console.ReadLine();

                Console.WriteLine("Digite el numero de factura");
                numeroFactura[pos] = Console.ReadLine();

                Console.WriteLine("Digite el monto a pagar");
                montoPagar[pos] = Console.ReadLine();
                
                //monto comision
                int montoCI = int.Parse(tipoServicio[pos]);
                double montoP = double.Parse(montoPagar[pos]);
                double resultado = 0;
                double comluz = 0.04 ; 
                double comtel = 0.055 ;
                double comagua = 0.065;
                
                if (montoCI == 1)
                {
                    resultado = montoP * comluz;
                    montoComision[pos] = Convert.ToString(resultado);
                }
                if (montoCI == 2)
                {
                    resultado = montoP * comtel;
                    montoComision[pos] = Convert.ToString(resultado);
                }
                if (montoCI == 3)
                {
                    resultado = montoP * comagua;
                    montoComision[pos] = Convert.ToString(resultado);
                }

                //monto deducido
                double montoC = double.Parse(montoComision[pos]);
                resultado = montoP - montoC;
                montoDeducido[pos] = Convert.ToString(resultado);

                Console.WriteLine("Digite el monto con el que va a pagar el cliente");
                montoPagaCliene[pos] = Console.ReadLine();
                
                int montoPC = int.Parse(montoPagaCliene[pos]);
                int montoPagarP = int.Parse(montoPagar[pos]);
                if (montoPC < montoPagarP)
                {
                    Console.WriteLine("El monto con el que va a pagar el cliente es menor al monto del servicio");
                    Console.WriteLine("Digite correctamente el monto con el que va a pagar el cliente");
                    montoPagaCliene[pos] = Console.ReadLine();
                    
                }
                //vuelto
                double montoPG = double.Parse(montoPagaCliene[pos]);
                resultado = montoPG - montoP;
                montoVuelto[pos] = Convert.ToString(resultado);

                numpago++;
                pos++;

                Console.WriteLine("Desea agregar otro trámite s/n");
                opcion = Convert.ToChar(Console.ReadLine());
            } while (opcion != 'n');
        }
        public void ConsultarPago()
        {
            Console.WriteLine("Ingrese el numero de pago a consultar:");
            string pagoConsultar = Console.ReadLine();
            Boolean existe = false;
            for (int i = 0; i < numeroPago.Length; i++)
            {
                if (pagoConsultar.Equals(numeroPago[i].ToString()))
                {
                    char opcion = 'n';
                    do
                    {
                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Consulta de datos");

                        Console.SetCursorPosition(7, 13);
                        Console.WriteLine("Numero de pago: ");
                        Console.SetCursorPosition(27, 13);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(30, 19);
                        Console.WriteLine("Dato encontrado en la posicion Vector: " + i);

                        Console.SetCursorPosition(30, 27);
                        Console.WriteLine("Presione enter para ver el registro");
                        Console.ReadLine();

                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Consulta de datos");

                        Console.SetCursorPosition(7, 13);
                        Console.WriteLine("Numero de pago: ");
                        Console.SetCursorPosition(27, 13);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(7, 14);
                        Console.WriteLine("fecha: ");
                        Console.SetCursorPosition(27, 14);
                        Console.WriteLine(fecha[i]);

                        Console.SetCursorPosition(50, 14);
                        Console.WriteLine("Hora:");
                        Console.SetCursorPosition(65, 14);
                        Console.WriteLine(hora[i]);

                        Console.SetCursorPosition(7, 16);
                        Console.WriteLine("Cédula");
                        Console.SetCursorPosition(27, 16);
                        Console.WriteLine(cedula[i]);

                        Console.SetCursorPosition(50, 16);
                        Console.WriteLine("Nombre:");
                        Console.SetCursorPosition(65, 16);
                        Console.WriteLine(nombre[i]);

                        Console.SetCursorPosition(7, 17);
                        Console.WriteLine("Apellido 1");
                        Console.SetCursorPosition(27, 17);
                        Console.WriteLine(apellido1[i]);

                        Console.SetCursorPosition(50, 17);
                        Console.WriteLine("Apellido 2:");
                        Console.SetCursorPosition(65, 17);
                        Console.WriteLine(apellido2[i]);

                        Console.SetCursorPosition(7, 19);
                        Console.WriteLine("Tipo de Servicio");
                        Console.SetCursorPosition(27, 19);
                        Console.WriteLine(tipoServicio[i]);

                        Console.SetCursorPosition(42, 19);
                        Console.WriteLine("[1-Electricidad 2-Telefono 3-Agua]");

                        Console.SetCursorPosition(7, 21);
                        Console.WriteLine("Número de factura: ");
                        Console.SetCursorPosition(30, 21);
                        Console.WriteLine(numeroFactura[i]);

                        Console.SetCursorPosition(50, 21);
                        Console.WriteLine("Monto Pagar:");
                        Console.SetCursorPosition(70, 21);
                        Console.WriteLine(montoPagar[i]);

                        Console.SetCursorPosition(7, 22);
                        Console.WriteLine("Comision autorizada:");
                        Console.SetCursorPosition(30, 22);
                        Console.WriteLine(montoComision[i]);

                        Console.SetCursorPosition(50, 22);
                        Console.WriteLine("Paga con:");
                        Console.SetCursorPosition(70, 22);
                        Console.WriteLine(montoPagaCliene[i]);

                        Console.SetCursorPosition(7, 23);
                        Console.WriteLine("Monto deducido: ");
                        Console.SetCursorPosition(30, 23);
                        Console.WriteLine(montoDeducido[i]);

                        Console.SetCursorPosition(50, 23);
                        Console.WriteLine("Vuelto: ");
                        Console.SetCursorPosition(70, 23);
                        Console.WriteLine(montoVuelto[i]);

                        Console.SetCursorPosition(50, 24);
                        Console.WriteLine("caja #: ");
                        Console.SetCursorPosition(70, 24);
                        Console.WriteLine(numeroCaja[i]);

                        Console.SetCursorPosition(30, 27);
                        Console.WriteLine("Desea continuar s/n?");
                        opcion = Convert.ToChar(Console.ReadLine());
                    } while (opcion != 's');
                   
                    existe = true;
                }
            }
            if (!existe)
            {
                char opcion = 'n';
                do
                {
                    Console.Clear();
                    Console.SetCursorPosition(27, 10);
                    Console.WriteLine("Sistema pago de servicios publicos");
                    Console.SetCursorPosition(30, 11);
                    Console.WriteLine("Tienda X - Consulta de datos");

                    Console.SetCursorPosition(30, 19);
                    Console.WriteLine("Pago no registrado");

                    Console.SetCursorPosition(30, 27);
                    Console.WriteLine("Desea continuar s/n?");
                    opcion = Convert.ToChar(Console.ReadLine());
                } while (opcion != 's');
            }
        }
        public void ModificarPago()
        {
            Console.WriteLine("Ingrese el numero de pago que desea modificar");
            buscarpago = Console.ReadLine();

            for (int i = 0; i < 10; i++)
            {
                if (numeroPago[i] == buscarpago)
                {
                    char opcion = 'n';
                    do
                    {
                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Modificar");

                        Console.SetCursorPosition(7, 13);
                        Console.WriteLine("Numero de pago: ");
                        Console.SetCursorPosition(27, 13);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(30, 19);
                        Console.WriteLine("Dato encontrado en la posicion Vector: " + i);

                        Console.SetCursorPosition(30, 27);
                        Console.WriteLine("Presione enter para ver el registro");
                        Console.ReadLine();

                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Modificar Pagos");

                        Console.SetCursorPosition(7, 13);
                        Console.WriteLine("Numero de pago: ");
                        Console.SetCursorPosition(27, 13);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(7, 14);
                        Console.WriteLine("A- Fecha: ");
                        Console.SetCursorPosition(27, 14);
                        Console.WriteLine(fecha[i]);

                        Console.SetCursorPosition(50, 14);
                        Console.WriteLine("B- Hora:");
                        Console.SetCursorPosition(65, 14);
                        Console.WriteLine(hora[i]);

                        Console.SetCursorPosition(7, 16);
                        Console.WriteLine("C- Cédula");
                        Console.SetCursorPosition(27, 16);
                        Console.WriteLine(cedula[i]);

                        Console.SetCursorPosition(50, 16);
                        Console.WriteLine("D- Nombre:");
                        Console.SetCursorPosition(65, 16);
                        Console.WriteLine(nombre[i]);

                        Console.SetCursorPosition(7, 17);
                        Console.WriteLine("E- Apellido 1");
                        Console.SetCursorPosition(27, 17);
                        Console.WriteLine(apellido1[i]);

                        Console.SetCursorPosition(50, 17);
                        Console.WriteLine("F- Apellido 2:");
                        Console.SetCursorPosition(65, 17);
                        Console.WriteLine(apellido2[i]);

                        Console.SetCursorPosition(7, 19);
                        Console.WriteLine("G- Tipo de Servicio");
                        Console.SetCursorPosition(27, 19);
                        Console.WriteLine(tipoServicio[i]);

                        Console.SetCursorPosition(42, 19);
                        Console.WriteLine("[1-Electricidad 2-Telefono 3-Agua]");

                        Console.SetCursorPosition(7, 21);
                        Console.WriteLine("H- Número de factura: ");
                        Console.SetCursorPosition(30, 21);
                        Console.WriteLine(numeroFactura[i]);

                        Console.SetCursorPosition(50, 21);
                        Console.WriteLine("Monto Pagar:");
                        Console.SetCursorPosition(70, 21);
                        Console.WriteLine(montoPagar[i]);

                        Console.SetCursorPosition(7, 22);
                        Console.WriteLine("Comision autorizada:");
                        Console.SetCursorPosition(30, 22);
                        Console.WriteLine(montoComision[i]);

                        Console.SetCursorPosition(50, 22);
                        Console.WriteLine("I- Paga con:");
                        Console.SetCursorPosition(70, 22);
                        Console.WriteLine(montoPagaCliene[i]);

                        Console.SetCursorPosition(7, 23);
                        Console.WriteLine("Monto deducido: ");
                        Console.SetCursorPosition(30, 23);
                        Console.WriteLine(montoDeducido[i]);

                        Console.SetCursorPosition(50, 23);
                        Console.WriteLine("Vuelto: ");
                        Console.SetCursorPosition(70, 23);
                        Console.WriteLine(montoVuelto[i]);

                        Console.SetCursorPosition(7, 25);
                        Console.WriteLine("Seleccione opción a modificar: ");
                        opcionmodificar = Console.ReadLine();

                        Console.SetCursorPosition(70, 25);
                        Console.WriteLine("Nuevo dato: ");
                        nuevodato = Console.ReadLine();

                        if (opcionmodificar == "A")
                        {
                            fecha[i] = DateTime.Now.ToString("dd-MM-yyyy");
                        }
                        if (opcionmodificar == "B")
                        {
                            hora[i] = DateTime.Now.ToString("hh:mm:ss");
                        }
                        if (opcionmodificar == "C")
                        {
                            cedula[i] = nuevodato;
                        }
                        if (opcionmodificar == "D")
                        {
                            nombre[i] = nuevodato;
                        }
                        if (opcionmodificar == "E")
                        {
                            apellido1[i] = nuevodato;
                        }
                        if (opcionmodificar == "F")
                        {
                            apellido2[i] = nuevodato;
                        }
                        if (opcionmodificar == "G")
                        {
                            tipoServicio[i] = nuevodato;
                        }
                        if (opcionmodificar == "H")
                        {
                            numeroFactura[i] = nuevodato;
                        }
                        if (opcionmodificar == "I")
                        {
                            montoPagaCliene[i] = nuevodato;
                        }

                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Modificar Pagos");

                        Console.SetCursorPosition(7, 13);
                        Console.WriteLine("Numero de pago: ");
                        Console.SetCursorPosition(27, 13);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(7, 14);
                        Console.WriteLine("A- Fecha: ");
                        Console.SetCursorPosition(27, 14);
                        Console.WriteLine(fecha[i]);

                        Console.SetCursorPosition(50, 14);
                        Console.WriteLine("B- Hora:");
                        Console.SetCursorPosition(65, 14);
                        Console.WriteLine(hora[i]);

                        Console.SetCursorPosition(7, 16);
                        Console.WriteLine("C- Cédula");
                        Console.SetCursorPosition(27, 16);
                        Console.WriteLine(cedula[i]);

                        Console.SetCursorPosition(50, 16);
                        Console.WriteLine("D- Nombre:");
                        Console.SetCursorPosition(65, 16);
                        Console.WriteLine(nombre[i]);

                        Console.SetCursorPosition(7, 17);
                        Console.WriteLine("E- Apellido 1");
                        Console.SetCursorPosition(27, 17);
                        Console.WriteLine(apellido1[i]);

                        Console.SetCursorPosition(50, 17);
                        Console.WriteLine("F- Apellido 2:");
                        Console.SetCursorPosition(65, 17);
                        Console.WriteLine(apellido2[i]);

                        Console.SetCursorPosition(7, 19);
                        Console.WriteLine("G- Tipo de Servicio");
                        Console.SetCursorPosition(27, 19);
                        Console.WriteLine(tipoServicio[i]);

                        Console.SetCursorPosition(42, 19);
                        Console.WriteLine("[1-Electricidad 2-Telefono 3-Agua]");

                        Console.SetCursorPosition(7, 21);
                        Console.WriteLine("H- Número de factura: ");
                        Console.SetCursorPosition(30, 21);
                        Console.WriteLine(numeroFactura[i]);

                        Console.SetCursorPosition(50, 21);
                        Console.WriteLine("Monto Pagar:");
                        Console.SetCursorPosition(70, 21);
                        Console.WriteLine(montoPagar[i]);

                        Console.SetCursorPosition(7, 22);
                        Console.WriteLine("Comision autorizada:");
                        Console.SetCursorPosition(30, 22);
                        Console.WriteLine(montoComision[i]);

                        Console.SetCursorPosition(50, 22);
                        Console.WriteLine("I- Paga con:");
                        Console.SetCursorPosition(70, 22);
                        Console.WriteLine(montoPagaCliene[i]);

                        Console.SetCursorPosition(7, 23);
                        Console.WriteLine("Monto deducido: ");
                        Console.SetCursorPosition(30, 23);
                        Console.WriteLine(montoDeducido[i]);

                        Console.SetCursorPosition(50, 23);
                        Console.WriteLine("Vuelto: ");
                        Console.SetCursorPosition(70, 23);
                        Console.WriteLine(montoVuelto[i]);

                        Console.SetCursorPosition(7, 25);
                        Console.WriteLine("datos modificados");

                        Console.WriteLine("Desea continuar s/n?");
                        opcion = Convert.ToChar(Console.ReadLine());
                    } while (opcion != 's');
                }
            }
        }
        public void EliminarPago()
        {
            Console.WriteLine("Ingrese el numero de pago a eliminar");
            buscarpago = Console.ReadLine();
            for (int i = 0; i < 10; i++)
            {
                if (numeroPago[i] == buscarpago)
                {
                    Console.Clear();
                    Console.SetCursorPosition(27, 10);
                    Console.WriteLine("Sistema pago de servicios publicos");
                    Console.SetCursorPosition(30, 11);
                    Console.WriteLine("Tienda X - Modificar Pagos");

                    Console.SetCursorPosition(7, 13);
                    Console.WriteLine("Numero de pago: ");
                    Console.SetCursorPosition(27, 13);
                    Console.WriteLine(numeroPago[i]);

                    Console.SetCursorPosition(7, 14);
                    Console.WriteLine("Fecha: ");
                    Console.SetCursorPosition(27, 14);
                    Console.WriteLine(fecha[i]);

                    Console.SetCursorPosition(50, 14);
                    Console.WriteLine("Hora:");
                    Console.SetCursorPosition(65, 14);
                    Console.WriteLine(hora[i]);

                    Console.SetCursorPosition(7, 16);
                    Console.WriteLine("Cédula");
                    Console.SetCursorPosition(27, 16);
                    Console.WriteLine(cedula[i]);

                    Console.SetCursorPosition(50, 16);
                    Console.WriteLine("Nombre:");
                    Console.SetCursorPosition(65, 16);
                    Console.WriteLine(nombre[i]);

                    Console.SetCursorPosition(7, 17);
                    Console.WriteLine("Apellido 1");
                    Console.SetCursorPosition(27, 17);
                    Console.WriteLine(apellido1[i]);

                    Console.SetCursorPosition(50, 17);
                    Console.WriteLine("Apellido 2:");
                    Console.SetCursorPosition(65, 17);
                    Console.WriteLine(apellido2[i]);

                    Console.SetCursorPosition(7, 19);
                    Console.WriteLine("Tipo de Servicio");
                    Console.SetCursorPosition(27, 19);
                    Console.WriteLine(tipoServicio[i]);

                    Console.SetCursorPosition(42, 19);
                    Console.WriteLine("[1-Electricidad 2-Telefono 3-Agua]");

                    Console.SetCursorPosition(7, 21);
                    Console.WriteLine("Número de factura: ");
                    Console.SetCursorPosition(30, 21);
                    Console.WriteLine(numeroFactura[i]);

                    Console.SetCursorPosition(50, 21);
                    Console.WriteLine("Monto Pagar:");
                    Console.SetCursorPosition(70, 21);
                    Console.WriteLine(montoPagar[i]);

                    Console.SetCursorPosition(7, 22);
                    Console.WriteLine("Comision autorizada:");
                    Console.SetCursorPosition(30, 22);
                    Console.WriteLine(montoComision[i]);

                    Console.SetCursorPosition(50, 22);
                    Console.WriteLine("Paga con:");
                    Console.SetCursorPosition(70, 22);
                    Console.WriteLine(montoPagaCliene[i]);

                    Console.SetCursorPosition(7, 23);
                    Console.WriteLine("Monto deducido: ");
                    Console.SetCursorPosition(30, 23);
                    Console.WriteLine(montoDeducido[i]);

                    Console.SetCursorPosition(50, 23);
                    Console.WriteLine("Vuelto: ");
                    Console.SetCursorPosition(70, 23);
                    Console.WriteLine(montoVuelto[i]);

                    Console.SetCursorPosition(7, 25);
                    Console.WriteLine("Desea elimnar los datos s/n?");
                    opcioneliminar = Console.ReadLine();
                    if (opcioneliminar == "s")
                    {
                        numeroPago[i] = "";
                        fecha[i] = "";
                        hora[i] = "";
                        cedula[i] = "";
                        nombre[i] = "";
                        apellido1[i] = "";
                        apellido2[i] = "";
                        numeroCaja[i] = 0;
                        tipoServicio[i] = "";
                        numeroFactura[i] = "";
                        montoPagar[i] = "";
                        montoComision[i] = "";
                        montoDeducido[i] = "";
                        montoPagaCliene[i] = "";
                        montoVuelto[i] = "";

                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Eliminar Pagos");
                        Console.SetCursorPosition(30, 19);
                        Console.WriteLine("La infomracion ya fue eliminada");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.Clear();
                        Console.SetCursorPosition(27, 10);
                        Console.WriteLine("Sistema pago de servicios publicos");
                        Console.SetCursorPosition(30, 11);
                        Console.WriteLine("Tienda X - Eliminar Pagos");
                        Console.SetCursorPosition(30, 19);
                        Console.WriteLine("la infomracion NO fue eliminada");
                        Console.ReadLine();
                    }
                }
            }
        }
        public void ReporteTotalPagos()
        {
            Console.Clear();
            Console.SetCursorPosition(30, 10);
            Console.WriteLine("Sistema pago de servicios publicos");
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Tienda X - Reporte Todos los Pagos");

            Console.SetCursorPosition(7, 13);
            Console.WriteLine("# pago");

            Console.SetCursorPosition(17, 13);
            Console.WriteLine("fecha");

            Console.SetCursorPosition(23, 13);
            Console.WriteLine("/Hora");

            Console.SetCursorPosition(32, 13);
            Console.WriteLine("Cédula");

            Console.SetCursorPosition(42, 13);
            Console.WriteLine("Nombre");

            Console.SetCursorPosition(51, 13);
            Console.WriteLine("Apellido1");

            Console.SetCursorPosition(63, 13);
            Console.WriteLine("Apellido2");

            Console.SetCursorPosition(74, 13);
            Console.WriteLine("Monto Recibo");

            
            for (int i = 0; i < numeroPago.Length; i++)
            {
                Console.SetCursorPosition(7, fila);
                Console.WriteLine(numeroPago[i]);

                Console.SetCursorPosition(17, fila);
                Console.WriteLine(fecha[i]);

                Console.SetCursorPosition(23, fila);
                Console.WriteLine(hora[i]);

                Console.SetCursorPosition(32, fila);
                Console.WriteLine(cedula[i]);

                Console.SetCursorPosition(42, fila);
                Console.WriteLine(nombre[i]);

                Console.SetCursorPosition(51, fila);
                Console.WriteLine(apellido1[i]);

                Console.SetCursorPosition(63, fila);
                Console.WriteLine(apellido2[i]);

                Console.SetCursorPosition(74, fila);
                Console.WriteLine(montoPagar[i]);

                fila++;
                if (montoPagar[i] == "")
                {

                }
                else
                {
                    int montoTotalP = int.Parse(montoPagar[i]);
                    montoTotal = montoTotal + montoTotalP;
                    totalReg++;
                }
                
            }
            Console.SetCursorPosition(7, 22);
            Console.WriteLine("=============================================================================");
            
            Console.SetCursorPosition(7, 23);
            Console.WriteLine("Total Regitros");

            Console.SetCursorPosition(22, 23);
            Console.WriteLine(totalReg);

            Console.SetCursorPosition(50, 23);
            Console.WriteLine("Monto Total");

            Console.SetCursorPosition(71, 23);
            Console.WriteLine(montoTotal);

            Console.SetCursorPosition(30, 25);
            Console.WriteLine("Presione enter para continuar");
            Console.ReadLine();
        }
        public void ReporteTiposServicios()
        {
            Console.Clear();
            Console.SetCursorPosition(30, 10);
            Console.WriteLine("Sistema pago de servicios publicos");
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Tienda X - Reporte Tipo de servicio");
            Console.SetCursorPosition(7, 12);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 15);
            Console.WriteLine("Seleccione codigo de Servicio         [1]-Electricidad [2]-Telefono [3]-Agua");

            Console.SetCursorPosition(7, 18);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 25);
            Console.WriteLine("Digite opcion seleccionada : ");
            opcionseleccionada = Console.ReadLine();

            Console.Clear();
            Console.SetCursorPosition(30, 10);
            Console.WriteLine("Sistema pago de servicios publicos");
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Tienda X - Reporte Tipo de servicio");

            Console.SetCursorPosition(7, 13);
            Console.WriteLine("# pago");

            Console.SetCursorPosition(17, 13);
            Console.WriteLine("fecha");

            Console.SetCursorPosition(23, 13);
            Console.WriteLine("/Hora");

            Console.SetCursorPosition(32, 13);
            Console.WriteLine("Cédula");

            Console.SetCursorPosition(42, 13);
            Console.WriteLine("Nombre");

            Console.SetCursorPosition(51, 13);
            Console.WriteLine("Apellido1");

            Console.SetCursorPosition(63, 13);
            Console.WriteLine("Apellido2");

            Console.SetCursorPosition(74, 13);
            Console.WriteLine("Monto Recibo");

            Console.SetCursorPosition(7, 30);
            Console.WriteLine("=============================================================================");
            char opcion = 'n';
            do
            {
                for (int i = 0; i < tipoServicio.Length; i++)
                {
                    if (opcionseleccionada == tipoServicio[i])
                    {
                    Console.SetCursorPosition(7, fila);
                    Console.WriteLine(numeroPago[i]);

                    Console.SetCursorPosition(17, fila);
                    Console.WriteLine(fecha[i]);

                    Console.SetCursorPosition(23, fila);
                    Console.WriteLine(hora[i]);

                    Console.SetCursorPosition(32, fila);
                    Console.WriteLine(cedula[i]);

                    Console.SetCursorPosition(42, fila);
                    Console.WriteLine(nombre[i]);

                    Console.SetCursorPosition(51, fila);
                    Console.WriteLine(apellido1[i]);

                    Console.SetCursorPosition(63, fila);
                    Console.WriteLine(apellido2[i]);

                    Console.SetCursorPosition(74, fila);
                    Console.WriteLine(montoPagar[i]);

                    fila++;

                        if (montoPagar[i] == "")
                        {

                        }
                        else
                        {
                            int montoTotalP = int.Parse(montoPagar[i]);
                            montoTotal = montoTotal + montoTotalP;
                            totalReg++;
                        }
                    }
                
                }
                Console.SetCursorPosition(7, 22);
                Console.WriteLine("=============================================================================");

                Console.SetCursorPosition(7, 23);
                Console.WriteLine("Total Regitros");

                Console.SetCursorPosition(22, 23);
                Console.WriteLine(totalReg);

                Console.SetCursorPosition(50, 23);
                Console.WriteLine("Monto Total");

                Console.SetCursorPosition(71, 23);
                Console.WriteLine(montoTotal);
                Console.SetCursorPosition(30, 27);
                Console.WriteLine("Desea continuar s/n?");
                opcion = Convert.ToChar(Console.ReadLine());
            } while (opcion != 's');

        }
        public void ReporteCodigoCaja()
        {
            Console.Clear();
            Console.SetCursorPosition(30, 10);
            Console.WriteLine("Sistema pago de servicios publicos");
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Tienda X - Reporte Codigo de cajero");
            Console.SetCursorPosition(7, 12);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 15);
            Console.WriteLine("Seleccione codigo de Servicio         [1]-Caja #1   [2]-Caja #2   [3]-Caja #3");

            Console.SetCursorPosition(7, 18);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 25);
            Console.WriteLine("Digite opcion seleccionada : ");
            opcionseleccionada = Console.ReadLine();
            int opcionseleccionadaa = int.Parse(opcionseleccionada);

            Console.Clear();
            Console.SetCursorPosition(30, 10);
            Console.WriteLine("Sistema pago de servicios publicos");
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Tienda X - Reporte Codigo de cajero");

            Console.SetCursorPosition(7, 13);
            Console.WriteLine("# pago");

            Console.SetCursorPosition(17, 13);
            Console.WriteLine("fecha");

            Console.SetCursorPosition(23, 13);
            Console.WriteLine("/Hora");

            Console.SetCursorPosition(32, 13);
            Console.WriteLine("Cédula");

            Console.SetCursorPosition(42, 13);
            Console.WriteLine("Nombre");

            Console.SetCursorPosition(52, 13);
            Console.WriteLine("Apellido1");

            Console.SetCursorPosition(63, 13);
            Console.WriteLine("Apellido2");

            Console.SetCursorPosition(74, 13);
            Console.WriteLine("Monto Recibo");

            Console.SetCursorPosition(7, 30);
            Console.WriteLine("=============================================================================");
            char opcion = 'n';
            do
            {
                for (int i = 0; i < tipoServicio.Length; i++)
                {
                    if (opcionseleccionadaa == numeroCaja[i])
                    {
                        Console.SetCursorPosition(7, fila);
                        Console.WriteLine(numeroPago[i]);

                        Console.SetCursorPosition(17, fila);
                        Console.WriteLine(fecha[i]);

                        Console.SetCursorPosition(23, fila);
                        Console.WriteLine(hora[i]);

                        Console.SetCursorPosition(31, fila);
                        Console.WriteLine(cedula[i]);

                        Console.SetCursorPosition(39, fila);
                        Console.WriteLine(nombre[i]);

                        Console.SetCursorPosition(48, fila);
                        Console.WriteLine(apellido1[i]);

                        Console.SetCursorPosition(60, fila);
                        Console.WriteLine(apellido2[i]);

                        Console.SetCursorPosition(71, fila);
                        Console.WriteLine(montoPagar[i]);

                        fila++;

                        if (montoPagar[i] == "")
                        {

                        }
                        else
                        {
                            int montoTotalP = int.Parse(montoPagar[i]);
                            montoTotal = montoTotal + montoTotalP;
                            totalReg++;
                        }
                    }
                }
                Console.SetCursorPosition(7, 22);
                Console.WriteLine("=============================================================================");

                Console.SetCursorPosition(7, 23);
                Console.WriteLine("Total Regitros");

                Console.SetCursorPosition(22, 23);
                Console.WriteLine(totalReg);

                Console.SetCursorPosition(50, 23);
                Console.WriteLine("Monto Total");

                Console.SetCursorPosition(71, 23);
                Console.WriteLine(montoTotal);

                Console.SetCursorPosition(30, 27);
                Console.WriteLine("Desea continuar s/n?");
                opcion = Convert.ToChar(Console.ReadLine());
            } while (opcion != 's');
        }
        public void ReporteDineroComisionado()
        {
            Console.Clear();
            Console.SetCursorPosition(30, 11);
            Console.WriteLine("Reporte Dinero Comisionado - Desglo por tipo de servicio");
            Console.SetCursorPosition(7, 12);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 15);
            Console.WriteLine("ITEM                    Cant. Transacciones                 Total Comisionado");

            Console.SetCursorPosition(7, 18);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(7, 19);
            Console.WriteLine("1- Electricidad");

            Console.SetCursorPosition(7, 20);
            Console.WriteLine("2- Telefono");

            Console.SetCursorPosition(7, 21);
            Console.WriteLine("3- Agua");

            char opcion = 'n';
            do
            {
                for (int i = 0; i < tipoServicio.Length; i++)
                {
                    if (tipoServicio[i]=="1")
                    {
                        electricidad++;
                        double montoP = double.Parse(montoComision[i]);
                        totalComElec = totalComElec + montoP;
                        TotalTransacciones++;
                        totalComisionado = totalComisionado + totalComElec;
                    }
                    if (tipoServicio[i] == "2")
                    {
                        telefono++;
                        double montoP = double.Parse(montoComision[i]);
                        totalComTel = totalComTel + montoP;
                        TotalTransacciones++;
                        totalComisionado = totalComisionado + totalComTel;
                    }
                    if (tipoServicio[i] == "3")
                    {
                        agua++;
                        double montoP = double.Parse(montoComision[i]);
                        totalComAgua = totalComAgua + montoP;
                        TotalTransacciones++;
                        totalComisionado = totalComisionado + totalComAgua;
                    }

                }
                Console.SetCursorPosition(46, 19);
                Console.WriteLine(electricidad);

                Console.SetCursorPosition(46, 20);
                Console.WriteLine(telefono);

                Console.SetCursorPosition(46, 21);
                Console.WriteLine(agua);

                Console.SetCursorPosition(77, 19);
                Console.WriteLine(totalComElec);

                Console.SetCursorPosition(77, 20);
                Console.WriteLine(totalComTel);

                Console.SetCursorPosition(77, 21);
                Console.WriteLine(totalComAgua);

                Console.SetCursorPosition(7, 22);
                Console.WriteLine("=============================================================================");

                Console.SetCursorPosition(7, 23);
                Console.WriteLine("Total");

                Console.SetCursorPosition(46, 23);
                Console.WriteLine(TotalTransacciones);

                Console.SetCursorPosition(77, 23);
                Console.WriteLine(totalComisionado);

                Console.SetCursorPosition(30, 27);
                Console.WriteLine("Desea continuar s/n?");
                opcion = Convert.ToChar(Console.ReadLine());
            } while (opcion != 's');
        }
    }
}