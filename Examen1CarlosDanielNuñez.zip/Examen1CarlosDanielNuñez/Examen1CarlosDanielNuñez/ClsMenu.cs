﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1CarlosDanielNuñez
{
    class ClsMenu
    {

        static int opcion;

        static ClsServicioPublico ServiciosPublicos= new ClsServicioPublico(); 


        public static void principal()  // metodo
        {
            do
            {
                Console.Clear();
                Console.WriteLine("===========================");
                Console.WriteLine("***** MENU PRINCIPAL ******");
                Console.WriteLine("1- Inicializar vectores");
                Console.WriteLine("2- Realizar Pagos");
                Console.WriteLine("3- Consultar Pagos");
                Console.WriteLine("4- Modificar Pagos");
                Console.WriteLine("5- Eliminar Pagos");
                Console.WriteLine("6- Submenú Reportes");
                Console.WriteLine("7- Salir");
                Console.WriteLine("Ingrese una opcion: ");
                opcion = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("===========================");

                switch (opcion)
                {
                    case 1:
                        ServiciosPublicos.InicializarVectores();                        
                        break;
                    case 2:
                        ServiciosPublicos.RealizarPago();
                        break;
                    case 3:
                        ServiciosPublicos.ConsultarPago();
                        break;
                    case 4:
                        ServiciosPublicos.ModificarPago();
                        break;
                    case 5:
                        ServiciosPublicos.EliminarPago();
                        break;
                    case 6:
                        secundario();
                        break;
                    case 7: break;
                    default:
                        break;
                }
            } while (opcion != 7);
        }
        public static void secundario()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("====================================");
                Console.WriteLine("***** SUBMENU REPORTES ******");
                Console.WriteLine("1- Ver todos los Pagos");
                Console.WriteLine("2- Ver Pagos por tipo de servicio");
                Console.WriteLine("3- Ver Pagos por código de caja");
                Console.WriteLine("4- Ver Dinero Comisionado por servicios");
                Console.WriteLine("5- Regresar Menú Principal");
                Console.WriteLine("Ingrese una opcion: ");
                Console.WriteLine("====================================");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {

                    case 1:
                        ServiciosPublicos.ReporteTotalPagos();
                        break;
                    case 2:
                        ServiciosPublicos.ReporteTiposServicios();
                        break;
                    case 3:
                        ServiciosPublicos.ReporteCodigoCaja();
                        break;
                    case 4:
                        ServiciosPublicos.ReporteDineroComisionado();
                        break;
                    case 5:
                        principal();
                        break;
                }
            } while (opcion != 3);
        }

    }
}