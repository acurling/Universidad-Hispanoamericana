﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_Vectores
{
    class ClsEstudiantes
    {
        string[] ced = new string[1];
        string[] nombre = new string[1];
        float[] nota = new float[1];
        string[] cond = new string[1];

        public ClsEstudiantes()
        {

        }

        public void InicializarEstudiante()
        {
            Array.Clear(ced, 0, ced.Length);
            Array.Clear(nombre, 0, nombre.Length);
            Array.Clear(nota, 0, nota.Length);
            Array.Clear(cond, 0, cond.Length);
        }
        public void IncluirEstudiantes()
        {
            char opc = 'y';
            byte cont = 0;
            float nota1 = 0, nota2 = 0, nota3 = 0, prom = 0;

            do
            {
                Console.WriteLine("Escriba el numero de cedula del estudiante");
                ced[cont] = Console.ReadLine();
                Console.WriteLine("Escriba el nombre del estudiante");
                nombre[cont] = Console.ReadLine();
                Console.WriteLine("Escriba la nota del primer trimestre del estudiante");
                nota1 = float.Parse(Console.ReadLine());
                Console.WriteLine("Escriba la nota del segundo trimestre del estudiante");
                nota2 = float.Parse(Console.ReadLine());
                Console.WriteLine("Escriba la nota del tercer trimestre del estudiante");
                nota3 = float.Parse(Console.ReadLine());

                prom = (nota1 + nota2 + nota3); prom /= 3;
                nota[cont] = prom;

                if (prom >= 70)
                {
                    cond[cont] = "Aprobado";
                }
                else if (prom < 70 && prom >= 60)
                    cond[cont] = "Aplazado";

                else
                    cond[cont] = "Reprobado";


                Console.WriteLine("Desea continuar añadiendo estudiantes (y/n)");
                opc = Convert.ToChar(Console.ReadLine());

                if (opc == 'y')
                {
                    Array.Resize(ref ced, ced.Length + 1);
                    Array.Resize(ref nombre, nombre.Length + 1);
                    Array.Resize(ref nota, nota.Length + 1);
                    Array.Resize(ref cond, cond.Length + 1);
                    cont++;
                }

            } while (opc == 'y');
        }
        public void ConsultarEstudiantes()
        {
            byte opc = 1;
            string consultCed = "";

            do
            {

                switch (opc)
                {
                    case 1:
                        Console.WriteLine("Escriba el numero de cedula del estudiante que desea consultar, solo numeros sin espacios");
                        consultCed = Console.ReadLine();
                        for (byte i = 0; i < ced.Length; i++)
                        {
                            if (ced[i].Equals(consultCed))
                            {
                                Console.WriteLine("Estos son los datos de la persona consultada");
                                Console.WriteLine("******************************");
                                Console.WriteLine("Cedula   Nombre   Promedio   Condicion");
                                Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");
                            }
                        }

                        Console.WriteLine("Digite 1 si desea continuar consultando estudiantes o 2 si desea salir al menu principal");
                        opc = Convert.ToByte(Console.ReadLine());
                        break;

                    case 2:
                        Console.WriteLine("Volviendo al menu principal");
                        break;
                }

            } while (opc != 2);


        }

        public void ModificarEstudiante()
        {
            byte opc = 1;
            char opc1 = 'n';
            string consultCed = "";


            do
            {

                switch (opc)
                {
                    case 1:
                        Console.WriteLine("Escriba el numero de cedula del estudiante al que desea modificarle sus datos, solo numeros sin espacios");
                        consultCed = Console.ReadLine();
                        for (byte i = 0; i < ced.Length; i++)
                        {
                            if (ced[i].Equals(consultCed))
                            {
                                Console.WriteLine("Estos son los datos de la persona consultada");
                                Console.WriteLine("******************************");
                                Console.WriteLine("Cedula   Nombre   Promedio   Condicion");
                                Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");

                                Console.WriteLine("Digite n para modificar el nombre o p para modificar el promedio");
                                opc1 = Convert.ToChar(Console.ReadLine());
                                if (opc1.Equals('n') && ced[i].Equals(consultCed))
                                {
                                    Console.WriteLine("Digite el nuevo nombre");
                                    nombre[i] = Console.ReadLine();
                                }
                                else if (opc1.Equals('p') && ced[i].Equals(consultCed))
                                {
                                    Console.WriteLine("Digite el nuevo promedio");
                                    nota[i] = (float)Convert.ToDouble(Console.ReadLine());

                                    if (nota[i] >= 70)
                                    {
                                        cond[i] = "Aprobado";
                                    }
                                    else if (nota[i] < 70 && nota[i] >= 60)
                                        cond[i] = "Aplazado";

                                    else
                                        cond[i] = "Reprobado";
                                }
                            }

                        }
                        Console.WriteLine("Digite 1 si desea continuar modificando informacion de estudiantes o 2 si desea salir al menu principal");
                        opc = Convert.ToByte(Console.ReadLine());
                        break;

                    case 2:
                        Console.WriteLine("Volviendo al menu principal");
                        break;
                }

            } while (opc != 2);


        }

        public void EliminarEstudiante()
        {
            byte opc = 1;
            string consultCed = "";


            do
            {

                switch (opc)
                {
                    case 1:
                        Console.WriteLine("Escriba el numero de cedula del estudiante que desea eliminar, solo numeros sin espacios");
                        consultCed = Console.ReadLine();
                        for (byte i = 0; i < ced.Length; i++)
                        {
                            if (ced[i].Equals(consultCed))
                            {
                                ced[i] = null;
                                nombre[i] = null;
                                nota[i] = (float)Convert.ToDouble(null);
                                cond[i] = null;

                                Console.WriteLine("Estudiante fue eliminado con exito");
                            }
                        }
                        Console.WriteLine("Digite 1 si desea continuar eliminando estudiantes o 2 si desea salir al menu principal");
                        opc = Convert.ToByte(Console.ReadLine());
                        break;

                    case 2:
                        Console.WriteLine("Volviendo al menu principal");
                        break;
                }

            } while (opc != 2);


        }

        public void CondEst()
        {
            byte opc = 1;
            byte opc1 = 0;

            do
            {

                switch (opc) {

                    case 1:

                        Console.WriteLine("Escriba 1 si desea ver los estudiantes aprobados, 2 si desea visualizar los aplazados o 3 si desea ver los reprobados");
                        opc1 = Convert.ToByte(Console.ReadLine());

                        Console.WriteLine("Estos son los datos de los reportes");
                        Console.WriteLine("******************************");
                        Console.WriteLine("Cedula   Nombre   Promedio   Condicion");

                        switch (opc1)
                        {
                            
                             case 1:
                                for (byte i = 0; i < ced.Length; i++)
                                {
                                    if (cond[i].Equals("Aprobado"))
                                    {  
                                        Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");
                                    }
                                }
                                Console.WriteLine("Digite 1 si desea consultar otra condicion o 2 si desea salir al menu principal");
                                opc = Convert.ToByte(Console.ReadLine());
                                break;

                            case 2:
                                for (byte i = 0; i < ced.Length; i++)
                                {
                                    if (cond[i].Equals("Aplazado"))
                                    {
                                        Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");
                                    }
                                }
                                Console.WriteLine("Digite 1 si desea consultar otra condicion o 2 si desea salir al menu principal");
                                opc = Convert.ToByte(Console.ReadLine());
                                break;

                            case 3:
                                for (byte i = 0; i < ced.Length; i++)
                                {
                                    if (cond[i].Equals("Reprobado"))
                                    {
                                        Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");
                                    }
                                }
                                Console.WriteLine("Digite 1 si desea consultar otra condicion o 2 si desea salir al menu principal");
                                opc = Convert.ToByte(Console.ReadLine());
                                break;

                        }
                        break;
                    case 2:
                        Console.WriteLine("Volviendo al menu principal");
                        break;
                }

            } while (opc != 2);


        }

        public void TodosDatos()
        {
            byte opc = 1;
            float mayor = 0, menor = 0;
            //int mayores = 0, menores=0; 
            do
            {
                Console.WriteLine("Estos son los datos del reporte general");
                Console.WriteLine("******************************");
                Console.WriteLine("Cedula   Nombre   Promedio   Condicion");
                switch (opc)
                {
                    case 1:
                        for (byte i = 0; i < ced.Length; i++)
                        {
                      
                                Console.WriteLine($"{ced[i]}     {nombre[i]}     {nota[i]}     {cond[i]}");
                            
                        }

                        for (int i = 0; i < ced.Length; i++)
                        {
                            if (mayor<=nota[i])
                            {
                                mayor = nota[i];
                                    
                            }
                            menor = mayor;

                            if (menor>=nota[i])
                            {
                                menor = nota[i];
                              
                            }
                        }
                        Console.WriteLine("El promedio mas alto es: "+mayor);
                        Console.WriteLine("El promedio mas bajo es: " + menor);
                        Console.WriteLine("Digite 1 si desea reportar nuevamente todos los datos");
                        opc = Convert.ToByte(Console.ReadLine());
                        break;

                    case 2:
                        Console.WriteLine("Volviendo al menu principal");
                        break;
                }

            } while (opc != 2);

        }

    }
}
