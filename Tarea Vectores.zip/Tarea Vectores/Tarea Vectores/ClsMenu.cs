﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_Vectores
{
    class ClsMenu
    {
        static ClsEstudiantes estudiante = new ClsEstudiantes();
        static byte opc = 0;

        public ClsMenu()
        {

        }
        public static void menu()
        {


            do
            {
                prinMenu();


                while (opc == 6)
                {
                    Console.WriteLine("1 - Reporte Estudiantes por Condicion");
                    Console.WriteLine("2 - Reporte todos los datos");
                    Console.WriteLine("3 - Regresar al menu principal");
                    opc = Convert.ToByte(Console.ReadLine());

                    switch (opc)
                    {
                        case 1:
                            estudiante.CondEst();
                            break;

                        case 2:
                            estudiante.TodosDatos();
                            break;

                        case 3:                    
                            prinMenu();
                            opc = 0;
                            break;
                    }
                }

            } while (opc != 7);
        }

        public static void prinMenu()
        {
            Console.WriteLine("**********Menu**********");
            Console.WriteLine("1 - Inicializar Vetores");
            Console.WriteLine("2 - Incluir Estudiantes");
            Console.WriteLine("3 - Consultar Estudiantes");
            Console.WriteLine("4 - Modificar Estudiantes");
            Console.WriteLine("5 - Eliminar Estudiantes");
            Console.WriteLine("6 - Submenu Reportes");
            Console.WriteLine("7 - Salir");
            Console.WriteLine("Digite lo que desea hacer");
            opc = Convert.ToByte(Console.ReadLine());

            switch (opc)
            {
                case 1:
                    estudiante.InicializarEstudiante();
                    break;

                case 2:
                    estudiante.IncluirEstudiantes();
                    break;

                case 3:
                    estudiante.ConsultarEstudiantes();
                    break;

                case 4:
                    estudiante.ModificarEstudiante();
                    break;

                case 5:
                    estudiante.EliminarEstudiante();
                    break;

                case 6:
                    
                    break;

                case 7:
                    Console.WriteLine("Clique en enter para salir");
                    break;
                default:
                    break;
            }
        }


}


            
}

            


        
    

