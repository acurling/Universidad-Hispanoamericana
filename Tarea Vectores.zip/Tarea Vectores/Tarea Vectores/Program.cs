﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_Vectores
{
    class Program
    {
        static void Main(string[] args)
        {
            ClsMenu.menu();
            Console.ReadKey();
        }
    }
}
