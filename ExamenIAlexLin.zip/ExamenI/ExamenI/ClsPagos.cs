﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenIAlexLin
{
    class ClsPagos
    {
        // atributos
        int[] numPago = new int[10];
        String[] fecha = new String[10];
        String[] hora = new String[10];
        String[] cedula = new string[10];
        String[] nombre = new string[10];
        String[] apellido1 = new string[10];
        String[] apellido2 = new string[10];
        int[] caja = new int[10];
        int[] tipoServicio = new int[10];
        int[] factura = new int[10];
        float[] montoPagar = new float[10];
        float[] comision = new float[10];
        float[] deducido = new float[10];
        float[] montoCliente = new float[10];
        float[] vuelto = new float[10];
        int posicion;

        public ClsPagos()
        {
            posicion = 0;
        }

        //metodos
        public void Inicializar()
        {
            for (int i = 0; i < cedula.Length; i++)
            {
                numPago[i] = 0;
                fecha[i] = "";
                hora[i] = "";
                cedula[i] = "";
                nombre[i] = "";
                apellido1[i] = "";
                apellido2[i] = "";
                caja[i] = 0;
                tipoServicio[i] = 0;
                factura[i] = 0;
                montoPagar[i] = 0.0f;
                montoCliente[i] = 0.0f;
                comision[i] = 0.0f;
                deducido[i] = 0.0f;
                montoCliente[i] = 0.0f;
                vuelto[i] = 0.0f;
                posicion = 0;
            }
            Console.WriteLine("");
            Console.WriteLine("Vectores inicializados!");
            Console.ReadLine();
        }

        public void Realizar()
        {
            Random rd = new Random();
            char seg;
            String temp ="";
            Boolean Isnum = false, val = true;
            int ser = 0;
            float numT = 0.0f;
            do
            {
                try
                {
                    if (posicion == 10)
                    {
                        Console.Clear();
                        Console.Write("VECTORES LLENOS - VOLVER A MENU PRINCIPAL");
                        Console.ReadLine();
                        break;
                    }
                    Console.Clear();
                    Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                    Console.WriteLine("\t\t\tTienda La Favorita - Ingreso de Datos");
                    PrintOut();
                    Console.SetCursorPosition(24, 3); //Numero de Pago
                    Console.WriteLine($"{numPago[posicion] = posicion + 1}");
                    Console.SetCursorPosition(64, 3); //Numero Caja
                    Console.WriteLine($"{caja[posicion] = rd.Next(1,4)}");
                    Console.SetCursorPosition(24, 4); //Fecha
                    Console.WriteLine($"{fecha[posicion] = DateTime.Now.ToString("dd/MM/yy")}");
                    Console.SetCursorPosition(64, 4); //Hora
                    Console.WriteLine($"{hora[posicion] = DateTime.Now.ToString("hh:mmtt")}");
                    Positioning(24, 6);         //Cedula
                    cedula[posicion] = Console.ReadLine().Trim().ToUpper();
                    Positioning(64, 6);     //Nombre
                    nombre[posicion] = Console.ReadLine().Trim().ToUpper(); 
                    Positioning(24, 7);     //Apellido1 
                    apellido1[posicion] = Console.ReadLine().Trim().ToUpper();
                    Positioning(64, 7);     //Apellido2
                    apellido2[posicion] = Console.ReadLine().Trim().ToUpper();
                    do
                    {
                        Positioning(24, 9);     //Tipo Servicio
                        temp = Console.ReadLine();
                        Isnum = int.TryParse(temp, out ser);
                        if (Isnum)
                        {
                            if (ser>=1 && ser<=3)
                            {
                                tipoServicio[posicion] = ser;
                            }
                            else
                            {
                                ErrorPosi(24, 9);
                                Isnum = false;
                            }
                        }
                        else
                        {
                            ErrorPosi(24, 9);
                        }
                    } while (!Isnum);
                    Positioning(24, 11);        //Numero Factura 
                    factura[posicion] = int.Parse(Console.ReadLine());
                    Positioning(64, 11);        //Monto Pagar
                    montoPagar[posicion] = float.Parse(Console.ReadLine());
                    do
                    {
                        Isnum = true;
                        Positioning(64, 12);        //Paga con
                        numT = float.Parse(Console.ReadLine());
                        if (numT >= montoPagar[posicion])
                        {
                            montoCliente[posicion] = numT;
                            Isnum = false;
                        }
                        else
                        {
                            ErrorPosi(64, 12);
                        }
                    } while (Isnum);
                    Console.SetCursorPosition(64, 13);    //Vuelto
                    Console.WriteLine($"{vuelto[posicion]=montoCliente[posicion]-montoPagar[posicion]}");
                    Console.SetCursorPosition(24, 12);   //Comision
                    if (tipoServicio[posicion]==1)
                    {
                        Console.WriteLine($"{comision[posicion]=montoPagar[posicion]*0.04f}");
                    }
                    if (tipoServicio[posicion] == 2)
                    {
                        Console.WriteLine($"{comision[posicion] = montoPagar[posicion] * 0.055f}");
                    }
                    if (tipoServicio[posicion] == 3)
                    {
                        Console.WriteLine($"{comision[posicion] = montoPagar[posicion] * 0.065f}");
                    }
                    Console.SetCursorPosition(24, 13);   //Monto deducido
                    Console.WriteLine($"{deducido[posicion]=montoPagar[posicion]-comision[posicion]}");
                    Console.WriteLine("");
                    if ((posicion+1)==numPago.Length)
                    {
                        Console.Write("\t\t\tVectores llenos - Volver a Menu Principal");
                        Console.ReadLine();
                        seg = 'n';
                    }
                    else
                    {
                        do
                        {
                            Console.Write("\t\t\t\tDesea Continuar S/N?  ");
                            Console.SetCursorPosition(53, 15);
                            seg = char.Parse(Console.ReadLine().ToLower().Trim());
                            if (seg == 'n' || seg == 's')
                            {
                                val = false;
                            }
                            else
                            {
                                Positioning(0, 15);
                                val = true;
                            }
                        } while (val != false );                     
                    }
                    ++posicion;
                }
                catch (Exception)
                {
                    Positioning(0,17);
                    Console.Write("*** Error Fatal - Empiece de nuevo con este registro ***");
                    Console.ReadLine();
                    seg = 's';
                }
            } while (seg != 'n');
        }

        public void Consultar()
        {
            String temp = "";
            char seg;
            Boolean Isnum = false, val = true;
            int ser = 0, t = 0;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                    Console.WriteLine("\t\t\tTienda La Favorita - Consulta de Datos");
                    Console.WriteLine("");
                    Console.Write("Numero de Pago:\t\t");
                    temp = Console.ReadLine();
                    Isnum = int.TryParse(temp, out ser);
                    if (Isnum)
                    {
                        if ((t = Existe(ser)) == -1)
                        {
                            Positioning(24, 7);
                            Console.WriteLine("Pago no se encuentra registrado");
                            Positioning(15, 15);
                            Console.Write("Presione cualquier tecla para volver al menu principal");
                            Console.ReadLine();
                            seg = 'n';
                        }
                        else
                        {
                            Positioning(24, 7);
                            Console.WriteLine($"Dato Encontrado Posicion Vector {t}");
                            Positioning(17, 15);
                            Console.Write("Presione cualquier Tecla para ver el Registro");
                            Console.ReadLine();
                            Console.Clear();
                            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                            Console.WriteLine("\t\t\tTienda La Favorita - Consulta de Datos");
                            PrintOut();
                            PrintValues(t);
                            Console.WriteLine("");
                            do
                            {
                                Console.Write("\t\t\tDesea Consultar otro Pago S/N?  ");
                                Console.SetCursorPosition(55,16);
                                seg = char.Parse(Console.ReadLine().ToLower().Trim());
                                if (seg == 'n' || seg == 's')
                                {
                                    val = false;
                                }
                                else
                                {
                                    Positioning(0, 16);
                                    val = true;
                                }
                            } while (val != false);
                        }
                    }
                    else
                    {
                        Positioning(24, 7);
                        Console.WriteLine("Numero de Pago Invalido...");
                        Positioning(15, 15);
                        Console.Write("Presione cualquier tecla para volver al menu principal");
                        Console.ReadLine();
                        seg = 's';
                    }
                }
                catch (Exception)
                {
                    Positioning(24,7);
                    Console.WriteLine("Opcion invalida...");
                    Positioning(15, 15);
                    Console.Write("Presione cualquier tecla para volver al menu principal");
                    Console.ReadLine();
                    seg = 'n';
                }
            } while (seg != 'n');
            
        }

        public void Modificar()
        {
            ConsoleKeyInfo cki;
            String temp = "";
            Boolean Isnum = false, seg = false, repe = true;
            int ser = 0, t = 0;
            try
            {
                Console.Clear();
                Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                Console.WriteLine("\t\t\tTienda La Favorita - Modificar Pagos");
                Console.WriteLine("");
                Console.Write("Numero de Pago:\t\t");
                temp = Console.ReadLine();
                Isnum = int.TryParse(temp, out ser);
                if (Isnum)
                {
                    if ((t = Existe(ser)) == -1)
                    {
                        Positioning(24, 7);
                        Console.WriteLine("Pago no se encuentra registrado");
                        Positioning(15, 15);
                        Console.Write("Presione cualquier tecla para volver al menu principal");
                        Console.ReadLine();
                    }
                    else
                    {
                        Positioning(24, 7);
                        Console.WriteLine($"Dato Encontrado Posicion Vector {t}");
                        Positioning(17, 15);
                        Console.Write("Presione cualquier Tecla para ver el Registro");
                        Console.ReadLine();
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                            Console.WriteLine("\t\t\tTienda La Favorita - Modificar Pagos");
                            PrintOutModi();
                            PrintValues(t);
                            Console.WriteLine("Seleccione opcion a modificar:\t\t_\t\tNuevo Dato:\t_");
                            Console.WriteLine("");
                            Console.Write("\t\t\t   Presione Esc para cancelar");
                            Positioning(40, 15);
                            cki = Console.ReadKey();
                            if (cki.Key == ConsoleKey.Escape)
                            {
                                seg = false;
                                return;
                            }
                            else
                            {
                                Positioning(10, 17);
                                Console.Write("                                                                                ");
                                Console.SetCursorPosition(40, 15);
                                Console.WriteLine($"{cki.Key}");
                                switch (cki.Key)
                                {
                                    case ConsoleKey.F:  // FECHA
                                        Positioning(72, 15);
                                        fecha[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.H:  // HORA
                                        Positioning(72, 15);
                                        hora[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.C:  //CEDULA
                                        Positioning(72, 15);
                                        cedula[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.N:  //NOMBRE
                                        Positioning(72, 15);
                                        nombre[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.A:  //APELLIDO1
                                        Positioning(72, 15);
                                        apellido1[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.B:  //APELLIDO2
                                        Positioning(72, 15);
                                        apellido2[t] = Console.ReadLine();
                                        break;
                                    case ConsoleKey.T:  //TIPO SERVICIO
                                        do
                                        {
                                            Positioning(72, 15);
                                            tipoServicio[t] = int.Parse(Console.ReadLine());
                                            if (tipoServicio[t] == 1)
                                            {
                                                comision[t] = montoPagar[t] * 0.04f;
                                            }
                                            if (tipoServicio[t] == 2)
                                            {
                                                comision[t] = montoPagar[t] * 0.055f;
                                            }
                                            if (tipoServicio[t] == 3)
                                            {
                                                comision[t] = montoPagar[t] * 0.065f;
                                            }
                                            deducido[t] = montoPagar[t] - comision[t];
                                        } while (tipoServicio[t] > 3 || tipoServicio[t] < 1); 
                                        break;
                                    case ConsoleKey.I:  //NUMERO FACTURA
                                        Positioning(72, 15);
                                        factura[t] = int.Parse(Console.ReadLine());
                                        break;
                                    case ConsoleKey.P:  //PAGA CON
                                        do
                                        {
                                            repe = true;
                                            Console.SetCursorPosition(72,15);
                                            Console.WriteLine("        ");
                                            Positioning(72, 15);
                                            montoCliente[t] = float.Parse(Console.ReadLine());
                                            if (montoCliente[t]>=montoPagar[t])
                                            {
                                                vuelto[t] = montoCliente[t] - montoPagar[t];
                                                repe = false;
                                            }                                           
                                        } while (repe);                                        
                                        break;
                                    default:
                                        break;
                                }
                                seg = true;
                            }
                        } while (seg);
                    }
                }
                else
                {
                    Positioning(27, 7);
                    Console.WriteLine("Numero de Pago Invalido...");
                    Positioning(15, 15);
                    Console.Write("Presione cualquier tecla para volver al menu principal");
                    Console.ReadLine();
                }
            }
            catch (Exception)
            {
                Console.Clear();
                Positioning(27, 7);
                Console.WriteLine("Opcion invalida...");
                Positioning(15, 15);
                Console.Write("Presione cualquier tecla para volver al menu principal");
                Console.ReadLine();
            }
        }

        public void Eliminar()
        {
            String temp = "";
            char con;
            Boolean Isnum = false;
            int ser = 0, t = 0;
            try
            {
                Console.Clear();
                Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                Console.WriteLine("\t\t\tTienda La Favorita - Eliminar Datos");
                Console.WriteLine("");
                Console.Write("Numero de Pago:\t\t");
                temp = Console.ReadLine();
                Isnum = int.TryParse(temp, out ser);
                if (Isnum)
                {
                    if ((t = Existe(ser)) == -1)
                    {
                        Positioning(24, 7);
                        Console.WriteLine("Pago no se encuentra registrado");
                        Positioning(15, 15);
                        Console.Write("Presione cualquier tecla para volver al menu principal");
                        Console.ReadLine();
                    }
                    else
                    {
                        Positioning(24, 7);
                        Console.WriteLine($"Dato Encontrado Posicion Vector {t}");
                        Positioning(17, 15);
                        Console.Write("Presione cualquier Tecla para ver el Registro");
                        Console.ReadLine();
                        Console.Clear();
                        Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                        Console.WriteLine("\t\t\tTienda La Favorita - Eliminar Datos");
                        PrintOut();
                        PrintValues(t);
                        Console.WriteLine("");
                        Console.Write("\t\t\t\tEsta seguro de eliminar el dato S/N? ");
                        con = char.Parse(Console.ReadLine().ToLower());
                        if (con == 's')
                        {
                            for (int i = t; i < cedula.Length - 1; i++)
                            {
                                numPago[i] = numPago[i+1];
                                fecha[i] = fecha[i + 1];
                                hora[i] = hora[i + 1];
                                cedula[i] = cedula[i + 1];
                                nombre[i] = nombre[i + 1];
                                apellido1[i] = apellido1[i + 1];
                                apellido2[i] = apellido2[i + 1];
                                caja[i] = caja[i + 1];
                                tipoServicio[i] = tipoServicio[i + 1];
                                factura[i] = factura[i + 1];
                                montoPagar[i] = montoPagar[i + 1];
                                montoCliente[i] = montoCliente[i + 1];
                                comision[i] = comision[i + 1];
                                deducido[i] = deducido[i + 1];
                                montoCliente[i] = montoCliente[i + 1];
                                vuelto[i] = vuelto[i + 1];
                            }
                            posicion--;
                            numPago[numPago.Length - 1 ] = 0;
                            fecha[fecha.Length - 1] = "";
                            hora[hora.Length - 1] = "";
                            cedula[cedula.Length - 1] = "";
                            nombre[nombre.Length - 1] = "";
                            apellido1[apellido1.Length - 1] = "";
                            apellido2[apellido2.Length - 1] = "";
                            caja[caja.Length - 1] = 0;
                            tipoServicio[tipoServicio.Length - 1] = 0;
                            factura[factura.Length - 1] = 0;
                            montoPagar[montoPagar.Length - 1] = 0.0f;
                            montoCliente[montoCliente.Length - 1] = 0.0f;
                            comision[comision.Length - 1] = 0.0f;
                            deducido[deducido.Length - 1] = 0.0f;
                            montoCliente[montoCliente.Length - 1] = 0.0f;
                            vuelto[vuelto.Length - 1] = 0.0f;
                            Console.Clear();
                            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                            Console.WriteLine("\t\t\tTienda La Favorita - Eliminar Datos");
                            Console.WriteLine("");
                            Positioning(24, 7);
                            Console.WriteLine($"*** La información ya fue eliminada ***");
                            Positioning(17, 15);
                            Console.Write("Presione cualquier Tecla para volver al Menu Principal");
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                            Console.WriteLine("\t\t\tTienda La Favorita - Eliminar Datos");
                            Console.WriteLine("");
                            Positioning(24, 7);
                            Console.WriteLine($"*** La información no fue eliminada ***");
                            Positioning(17, 15);
                            Console.Write("Presione cualquier Tecla para volver al Menu Principal");
                        }
                        Console.ReadLine();
                    }
                }
                else
                {
                    Positioning(24, 7);
                    Console.WriteLine("Numero de Pago Invalido");
                    Positioning(15, 15);
                    Console.Write("Presione cualquier tecla para volver al menu principal");
                    Console.ReadLine();
                }
            }
            catch (Exception)
            {
                Console.Clear();
                Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                Console.WriteLine("\t\t\tTienda La Favorita - Eliminar Datos");
                Positioning(24, 7);
                Console.WriteLine("Opcion invalida...");
                Positioning(15, 15);
                Console.Write("Presione cualquier tecla para volver al menu principal");
                Console.ReadLine();
            }
        }

        public void RepServicio()
        {
            int op;
            Boolean repe = true;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                    Console.WriteLine("\tTienda La Favorita - Reporte Todos los Pagos por Tipo de Servicios");
                    Console.WriteLine("=========================================================================================");
                    Console.WriteLine("");
                    Console.WriteLine("Seleccione codigo de servicio\t\t[1]Electricidad [2]Telefono [3]Agua");
                    Console.WriteLine("");
                    Console.WriteLine("=========================================================================================");
                    Positioning(14, 15);
                    Console.Write("Seleccione la opcion del 1 al 3");
                    Positioning(30, 4);
                    op = int.Parse(Console.ReadLine());
                    if (op == 1 || op == 2 || op == 3)
                    {
                        repe = false;
                    }
                    else
                    {
                        Console.SetCursorPosition(14, 12);
                        Console.Write("Codigo de servicio no existe");
                        Console.ReadLine();
                        repe = true;
                        op = 0;
                    }
                }
                catch (Exception)
                {
                    Console.SetCursorPosition(14, 12);
                    Console.Write("Codigo de servicio no valido");
                    Console.ReadLine();
                    repe = true;
                    op = 0;
                }              
            } while (repe);
            Console.Clear();
            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
            Console.WriteLine("\tTienda La Favorita - Reporte Todos los Pagos por Tipo de Servicios");
            Imprimir(1, op); 
        }

        public void RepTodo()
        {
            Console.Clear();
            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
            Console.WriteLine("\t\t  Tienda La Favorita - Reporte Todos los Pagos");
            Imprimir(0,0);
        }

        public void RepCodCaja()
        {
            int op;
            Boolean repe = true;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
                    Console.WriteLine("\tTienda La Favorita - Reporte Todos los Pagos por Código de Caja");
                    Console.WriteLine("=========================================================================================");
                    Console.WriteLine("");
                    Console.WriteLine("Seleccione codigo de caja\t\t[1]Caja#1 [2]Caja#2 [3]Caja#3");
                    Console.WriteLine("");
                    Console.WriteLine("=========================================================================================");
                    Positioning(14, 15);
                    Console.Write("Seleccione la opcion del 1 al 3");
                    Positioning(30, 4);
                    op = int.Parse(Console.ReadLine());
                    if (op == 1 || op == 2 || op == 3)
                    {
                        repe = false;
                    }
                    else
                    {
                        Console.SetCursorPosition(14, 12);
                        Console.Write("Codigo de servicio no existe");
                        Console.Read();
                        repe = true;
                        op = 0;
                    }
                }
                catch (Exception)
                {
                    Console.SetCursorPosition(14, 12);
                    Console.Write("Codigo de servicio no valido");
                    Console.ReadLine();
                    repe = true;
                    op = 0; ;
                }              
            } while (repe);
            Console.Clear();
            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
            Console.WriteLine("\tTienda La Favorita - Reporte Todos los Pagos por Código de Caja");
            Imprimir(2, op);
        }

        public void Imprimir(int r, int z)
        {
            int cont = 0;
            float suma = 0;
            Console.WriteLine("");
            Console.WriteLine("#Pago\tFecha-Hora\tCedula\tNombre\tApellido1\tApellido2\tMonto Recibo");
            Console.WriteLine("=========================================================================================");
            for (int i = 0; i < posicion; i++)
            {
                if (r == 0)
                {
                    Console.WriteLine($"{numPago[i]}    {fecha[i]}T{hora[i]}\t{cedula[i]}\t{nombre[i]}\t{apellido1[i]}\t\t{apellido2[i]}\t\t{montoPagar[i]}");
                    cont++;
                    suma += montoPagar[i];
                }
                if (r == 1)
                {
                    if (tipoServicio[i] == z)
                    {
                        Console.WriteLine($"{numPago[i]}    {fecha[i]}T{hora[i]}\t{cedula[i]}\t{nombre[i]}\t{apellido1[i]}\t\t{apellido2[i]}\t\t{montoPagar[i]}");
                        cont++;
                        suma += montoPagar[i];
                    }
                }
                if (r == 2)
                {
                    if (caja[i] == z)
                    {
                        Console.WriteLine($"{numPago[i]}    {fecha[i]}T{hora[i]}\t{cedula[i]}\t{nombre[i]}\t{apellido1[i]}\t\t{apellido2[i]}\t\t{montoPagar[i]}");
                        cont++;
                        suma += montoPagar[i];
                    }
                }
            }
            Console.WriteLine("=========================================================================================");
            Console.WriteLine($"Total de Registros {cont}\t\t\t\t\tMonto Total\t{suma}");
            Positioning(14, 15);
            Console.Write("Presione cualquier tecla para volver al menu principal");
            Console.ReadLine();
        }

        public void RepComiServicio()
        {
            float[] comis= { 0,0,0};
            int[] cant = { 0,0,0};
            Console.Clear();
            for (int i = 0; i < posicion; i++)
            {
                if (tipoServicio[i] == 1) // Electricidad
                {
                    cant[0]++;
                    comis[0] += comision[i];
                }
                if (tipoServicio[i] == 2) // Telefono
                {
                    cant[1]++;
                    comis[1] += comision[i];
                }
                if (tipoServicio[i] == 3) // Agua
                {
                    cant[2]++;
                    comis[2] += comision[i];
                }
            }
            Console.WriteLine("\t\t\t Sistema Pago de Servicios Publicos");
            Console.WriteLine("Tienda La Favorita - Reporte Dinero Comisionado - Desgloce por Tipo de Servicio");
            Console.WriteLine("=========================================================================================");
            Console.WriteLine("ITEM\t\tCant. Transacciones\t\tTotal Comisionado");
            Console.WriteLine("=========================================================================================");
            Console.WriteLine($"1-Electricidad\t\t{cant[0]}\t\t\t\t{comis[0]}");
            Console.WriteLine($"2-Telefono\t\t{cant[1]}\t\t\t\t{comis[1]}");
            Console.WriteLine($"3-Agua\t\t\t{cant[2]}\t\t\t\t{comis[2]}");
            Console.WriteLine("=========================================================================================");
            Console.WriteLine($"Total\t\t\t{cant.Sum()}\t\t\t\t{comis.Sum()}");
            Console.WriteLine("=========================================================================================");
            Console.Write("\tPulse cualquier tecla para regresar al submenu de reportes");
            Console.ReadLine();
        }

        public void PrintOut() 
        {
            Console.WriteLine("");
            Console.WriteLine("Numero de Pago:\t\t_\t\t\tNumero Caja:\t_");
            Console.WriteLine("Fecha:\t\t\t_\t\t\tHora:\t\t_");
            Console.WriteLine("");
            Console.WriteLine("Cedula:\t\t\t_\t\t\tNombre:\t\t_");
            Console.WriteLine("Apellido1:\t\t_\t\t\tApellido2:\t_");
            Console.WriteLine("");
            Console.WriteLine("Tipo de Servicio:\t_ \t[1-Electricidad; 2-Telefono; 3-Agua]");
            Console.WriteLine("");
            Console.WriteLine("Numero de Factura:\t_\t\tMonto Pagar:\t\t_");
            Console.WriteLine("Comision autorizada:\t_\t\tPaga con:\t\t_");
            Console.WriteLine("Monto deducido:\t\t_\t\tVuelto:\t\t\t_");
        }

        public void PrintOutModi()
        {
            Console.WriteLine("");
            Console.WriteLine("Numero de Pago:\t\t_\t\t\tNumero Caja:\t_");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("F-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Fecha:\t\t\t_\t\t  Hora:\t\t_");
            Console.SetCursorPosition(48,4);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("H-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0,5);
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("C-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Cedula:\t\t_\t\t\t  Nombre:\t_");
            Console.SetCursorPosition(48,6);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("N-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0,7);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("A-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Apellido1:\t\t_\t\t\t  Apellido2:\t_");
            Console.SetCursorPosition(48, 7);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("B-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0, 8);
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("T-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Tipo de Servicio:\t_ \t[1-Electricidad; 2-Telefono; 3-Agua]");
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("I-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Numero de Factura:\t_\t\t\tMonto Pagar:\t_");
            Console.WriteLine("Comision autorizada:\t_\t\t\t  Paga con:\t_");
            Console.SetCursorPosition(48, 12);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("P-");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0, 13);
            Console.WriteLine("Monto deducido:\t\t_\t\t\tVuelto:\t\t_");
        }

        public void Positioning(int c, int f)
        {
            Console.SetCursorPosition(c, f);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("X");
            Console.SetCursorPosition(c, f);
            Console.ForegroundColor = ConsoleColor.Black;
        }

        public void ErrorPosi(int c, int f) 
        {
            Console.SetCursorPosition(c, f);
            Console.Write("Error");
            Console.ReadLine();
            Console.SetCursorPosition(c, f);
            Console.WriteLine("     ");
        }

        public int Existe(int pa)
        {
            int p = 0;
            p = Array.IndexOf(numPago, pa);
            return p;
        }

        public void PrintValues(int pos)
        {
            Console.SetCursorPosition(24, 3); //Numero de Pago
            Console.WriteLine($"{numPago[pos]}");
            Console.SetCursorPosition(64, 3); //Numero Caja
            Console.WriteLine($"{caja[pos]}");
            Console.SetCursorPosition(24, 4); //Fecha
            Console.WriteLine($"{fecha[pos]}");
            Console.SetCursorPosition(64, 4); //Hora
            Console.WriteLine($"{hora[pos]}");
            Console.SetCursorPosition(24, 6);         //Cedula
            Console.WriteLine(cedula[pos]);
            Console.SetCursorPosition(64, 6);     //Nombre
            Console.WriteLine($"{nombre[pos]}");
            Console.SetCursorPosition(24, 7);     //Apellido1 
            Console.WriteLine($"{apellido1[pos]}");
            Console.SetCursorPosition(64, 7);     //Apellido2
            Console.WriteLine($"{apellido2[pos]}");
            Console.SetCursorPosition(24, 9);     //Tipo Servicio
            Console.WriteLine($"{tipoServicio[pos]}");
            Console.SetCursorPosition(24, 11);        //Numero Factura 
            Console.WriteLine($"{factura[pos]}");
            Console.SetCursorPosition(64, 11);        //Monto Pagar
            Console.WriteLine($"{montoPagar[pos]}");
            Console.SetCursorPosition(64, 12);        //Paga con
            Console.WriteLine($"{montoCliente[pos]}");
            Console.SetCursorPosition(64, 13);    //Vuelto
            Console.WriteLine($"{vuelto[pos]}");
            Console.SetCursorPosition(24, 12);   //Comision
            Console.WriteLine($"{comision[pos]}");
            Console.SetCursorPosition(24, 13);   //Monto deducido
            Console.WriteLine($"{deducido[pos]}");
            Console.WriteLine("");
        }
    }
}
