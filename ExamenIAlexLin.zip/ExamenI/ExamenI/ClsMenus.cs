﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenIAlexLin
{
    class ClsMenus
    {
        static int opcion; //  VAR GLOBAL
        static ClsPagos pago = new ClsPagos();

        public void Principal()
        {
            opcion = 0;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("******** MENU PRINCIPAL ********");
                    Console.WriteLine("  1. Inicializar Vectores");
                    Console.WriteLine("  2. Realizar Pagos");
                    Console.WriteLine("  3. Consultar Pagos");
                    Console.WriteLine("  4. Modificar Pagos");
                    Console.WriteLine("  5. Eliminar Pagos");
                    Console.WriteLine("  6. Submenú Reportes");
                    Console.WriteLine("  7. Salir");
                    Console.WriteLine("--------------------------------");
                    Console.Write("Digite una opcion: ");
                    opcion = int.Parse(Console.ReadLine());
                    switch (opcion)
                    {
                        case 1:
                            pago.Inicializar();
                            break;
                        case 2:
                            pago.Realizar();
                            break;
                        case 3:
                            pago.Consultar();
                            break;
                        case 4:
                            pago.Modificar();
                            break;
                        case 5:
                            pago.Eliminar();
                            break;
                        case 6:
                            Reportes();
                            break;
                        case 7:
                            break;
                        default:
                            Console.Write("Opcion no Existe - Intente de nuevo");
                            Console.ReadLine();
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.Write("Opcion Invalida - Intente de nuevo");
                    Console.ReadLine();
                }               
            } while (opcion != 7);
        }

        public void Reportes()
        {
            opcion = 0;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("************* MENU REPORTES *************");
                    Console.WriteLine("  1. Ver todos los Pagos");
                    Console.WriteLine("  2. Ver Pagos por tipo de servicio");
                    Console.WriteLine("  3. Ver Pagos por código de caja");
                    Console.WriteLine("  4. Ver Dinero Comisionado por servicios");
                    Console.WriteLine("  5. Regresar Menú Principal");
                    Console.WriteLine("-----------------------------------------");
                    Console.Write("Digite una opcion: ");
                    opcion = int.Parse(Console.ReadLine());
                    switch (opcion)
                    {
                        case 1:
                            pago.RepTodo();
                            break;
                        case 2:
                            pago.RepServicio();
                            break;
                        case 3:
                            pago.RepCodCaja();
                            break;
                        case 4:
                            pago.RepComiServicio();
                            break;
                        case 5:
                            break;
                        default:
                            Console.Write("Opcion no Existe - Intente de nuevo");
                            Console.ReadLine();
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.Write("Opcion Invalida - Intente de nuevo");
                    Console.ReadLine();
                }            
            } while (opcion != 5);
        }
    }
}
