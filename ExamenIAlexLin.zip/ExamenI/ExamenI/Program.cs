﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenIAlexLin
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(90,20);
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            ClsMenus menuP = new ClsMenus();
            menuP.Principal();
        }
    }
}
